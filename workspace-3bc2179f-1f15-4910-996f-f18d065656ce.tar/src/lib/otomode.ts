// ---------------------------------------------------------------------------
// Otomode — Intra-Provider Smart Fallback
//
// A synthetic model (id: "otomode") that never maps to a fixed route.
// When the agent runner receives "otomode" as the selected model, it:
//   1. dynamically queries the model registry for all FREE models of the
//      provider (getFreeModelsByProvider),
//   2. re-ranks the chain with live health signals from telemetry,
//   3. attempts each candidate in order — including a stream-probe phase
//      that verifies the first content chunk before committing the SSE
//      response — and transparently serves from the first healthy model.
// ---------------------------------------------------------------------------

import ZAI from "z-ai-web-dev-sdk";
import type { Route } from "@prisma/client";
import { db } from "@/lib/db";
import {
  buildMessages,
  createSSETransformer,
  estimateTokens,
  lastUserPreview,
  logTelemetry,
  makeCompletionId,
  openAIError,
  type GatewayMessage,
  type RunOptions,
} from "@/lib/gateway";
import {
  getFreeModelsByProvider,
  OTOMODE_ID,
  OTOMODE_NAME,
  type ProviderId,
} from "@/lib/model-registry";

const OTOMODE_PROVIDER: ProviderId = "zai";
const HEALTH_WINDOW_MS = 15 * 60 * 1000; // 15 min lookback for health signals
const PROBE_TIMEOUT_MS = 10_000; // max wait for the first content chunk per model

// ---------------------------------------------------------------------------
// Chain planning (dynamic registry query + live health re-ranking)
// ---------------------------------------------------------------------------

export interface OtomodeChainEntry {
  id: string;
  name: string;
  tier: string;
  priority: number;
  contextWindow: number;
  speedTier: string;
  description: string;
  health: {
    recentCalls: number;
    recentFails: number;
    failRate: number;
    state: "healthy" | "degraded" | "unknown";
  };
}

export interface OtomodePlan {
  model: typeof OTOMODE_ID;
  name: typeof OTOMODE_NAME;
  provider: ProviderId;
  strategy: string;
  chain: OtomodeChainEntry[];
}

async function recentHealth(modelIds: string[]): Promise<Map<string, { calls: number; fails: number }>> {
  const since = new Date(Date.now() - HEALTH_WINDOW_MS);
  const rows = await db.requestLog.findMany({
    where: { alias: OTOMODE_ID, model: { in: modelIds }, createdAt: { gte: since } },
    select: { model: true, status: true },
  });
  const map = new Map<string, { calls: number; fails: number }>();
  for (const r of rows) {
    const entry = map.get(r.model) ?? { calls: 0, fails: 0 };
    entry.calls += 1;
    if (r.status >= 400) entry.fails += 1;
    map.set(r.model, entry);
  }
  return map;
}

/** Builds the live fallback plan: free models of the provider, health-ranked. */
export async function buildOtomodePlan(): Promise<OtomodePlan> {
  // 1) Dynamic registry query — all free models for this provider.
  const free = getFreeModelsByProvider(OTOMODE_PROVIDER);

  // 2) Live health signals from recent otomode attempts.
  const health = await recentHealth(free.map((m) => m.id));

  const entries: OtomodeChainEntry[] = free.map((m) => {
    const h = health.get(m.id) ?? { calls: 0, fails: 0 };
    const failRate = h.calls > 0 ? h.fails / h.calls : 0;
    const state: OtomodeChainEntry["health"]["state"] =
      h.calls === 0 ? "unknown" : h.calls >= 2 && failRate >= 0.5 ? "degraded" : "healthy";
    return {
      id: m.id,
      name: m.name,
      tier: m.tier,
      priority: m.priority,
      contextWindow: m.contextWindow,
      speedTier: m.speedTier,
      description: m.description,
      health: { recentCalls: h.calls, recentFails: h.fails, failRate, state },
    };
  });

  // 3) Smart re-ranking: healthy/unknown models keep registry priority order;
  //    degraded models sink below them (least-bad first).
  entries.sort((a, b) => {
    const aBad = a.health.state === "degraded" ? 1 : 0;
    const bBad = b.health.state === "degraded" ? 1 : 0;
    if (aBad !== bBad) return aBad - bBad;
    if (aBad && bBad) return a.health.failRate - b.health.failRate;
    return a.priority - b.priority;
  });

  return {
    model: OTOMODE_ID,
    name: OTOMODE_NAME,
    provider: OTOMODE_PROVIDER,
    strategy: `Dynamically resolved from the model registry: all free ${OTOMODE_PROVIDER} models, re-ranked by 15-minute failure telemetry. Tries each in order until one streams.`,
    chain: entries,
  };
}

// ---------------------------------------------------------------------------
// SSE helpers for the probe phase
// ---------------------------------------------------------------------------

interface SseProbeState {
  hasContent: boolean;
  error?: string;
}

/** Parses complete SSE lines; keeps trailing partial line in `buffer`. Exported for tests. */
export function scanSseForSignal(buffer: string): { signal: SseProbeState; leftover: string } {
  const lines = buffer.split("\n");
  const leftover = lines.pop() ?? "";
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("data:")) continue;
    const dataStr = trimmed.slice(5).trim();
    if (!dataStr || dataStr === "[DONE]") continue;
    try {
      const parsed = JSON.parse(dataStr);
      if (parsed?.error) {
        return { signal: { hasContent: false, error: parsed.error?.message || "Upstream error" }, leftover };
      }
      const choice = parsed?.choices?.[0];
      const delta = choice?.delta?.content ?? choice?.message?.content ?? choice?.text;
      if (typeof delta === "string" && delta) {
        return { signal: { hasContent: true }, leftover };
      }
    } catch {
      /* malformed line — keep scanning */
    }
  }
  return { signal: { hasContent: false }, leftover };
}

type ProbeResult =
  | { ok: true; reader: ReadableStreamDefaultReader<Uint8Array>; buffered: Uint8Array[] }
  | { ok: false; detail: string };

/**
 * Reads the upstream stream until the first content chunk (or failure).
 * Buffered chunks are replayed verbatim on commit so the client never
 * misses a byte. No content within the deadline => try the next model.
 */
export async function probeUpstreamStream(stream: ReadableStream<Uint8Array>): Promise<ProbeResult> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  const buffered: Uint8Array[] = [];
  let sseBuffer = "";
  const deadline = Date.now() + PROBE_TIMEOUT_MS;

  try {
    for (;;) {
      const remaining = deadline - Date.now();
      if (remaining <= 0) {
        await reader.cancel().catch(() => {});
        return { ok: false, detail: `no first token within ${PROBE_TIMEOUT_MS / 1000}s` };
      }
      const timer = new Promise<{ timeout: true }>((resolve) => setTimeout(() => resolve({ timeout: true }), remaining));
      const result = await Promise.race([reader.read(), timer]);
      if ("timeout" in result) {
        await reader.cancel().catch(() => {});
        return { ok: false, detail: `no first token within ${PROBE_TIMEOUT_MS / 1000}s` };
      }
      const { done, value } = result;
      if (done) return { ok: false, detail: "stream ended before any content" };
      if (value) {
        buffered.push(value);
        sseBuffer += decoder.decode(value, { stream: true });
      }
      const { signal, leftover } = scanSseForSignal(sseBuffer);
      sseBuffer = leftover;
      if (signal.error) {
        await reader.cancel().catch(() => {});
        return { ok: false, detail: signal.error };
      }
      if (signal.hasContent) return { ok: true, reader, buffered };
    }
  } catch (err) {
    await reader.cancel().catch(() => {});
    return { ok: false, detail: err instanceof Error ? err.message : "probe read failure" };
  }
}

/** Relays the already-probed stream (buffered prefix + live tail) through the OpenAI transformer. Exported for tests. */
export function replayProbedStream(
  probe: Extract<ProbeResult, { ok: true }>,
  transformer: TransformStream<Uint8Array, Uint8Array>
): ReadableStream<Uint8Array> {
  const source = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        for (const chunk of probe.buffered) controller.enqueue(chunk);
        for (;;) {
          const { done, value } = await probe.reader.read();
          if (done) break;
          if (value) controller.enqueue(value);
        }
      } catch {
        /* mid-stream failure after commit — transformer flush finalizes the SSE */
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
  });
  return source.pipeThrough(transformer);
}

// ---------------------------------------------------------------------------
// The Otomode agent-runner path
// ---------------------------------------------------------------------------

interface AttemptRecord {
  model: string;
  ok: boolean;
  detail: string;
  ms: number;
}

export async function runOtomodeCompletion(opts: RunOptions): Promise<Response> {
  const startedAt = Date.now();
  const plan = await buildOtomodePlan();

  if (plan.chain.length === 0) {
    return openAIError(
      502,
      `Otomode: no free models registered for provider '${OTOMODE_PROVIDER}'. Add entries to the model registry.`,
      "api_error"
    );
  }

  // No route/system prefix for the synthetic model — pass messages through sanitized.
  const prepared = buildMessages(opts.messages, "");
  const promptChars = prepared.reduce((acc, m) => acc + m.content.length, 0);
  const promptPreview = lastUserPreview(prepared);
  const keyName = opts.apiKeyRecord?.name ?? "Playground";
  const keyId = opts.apiKeyRecord?.id ?? null;
  const created = Math.floor(Date.now() / 1000);
  const chainIds = plan.chain.map((c) => c.id);
  const attempts: AttemptRecord[] = [];

  let zai: Awaited<ReturnType<typeof ZAI.create>>;
  try {
    zai = await ZAI.create();
  } catch (err) {
    const message = err instanceof Error ? err.message : "ZAI init failed";
    await logTelemetry({
      alias: OTOMODE_ID, model: "none", status: 502, stream: opts.stream,
      latencyMs: Date.now() - startedAt, promptChars, completionChars: 0,
      promptPreview, responsePreview: "", error: message, source: opts.source, keyId, keyName,
    });
    return openAIError(502, `Otomode: upstream init failed — ${message}`, "api_error");
  }

  /** Records a failed upstream attempt (telemetry row feeds future health ranking). */
  const recordFailure = async (modelId: string, detail: string, stream: boolean) => {
    attempts.push({ model: modelId, ok: false, detail, ms: Date.now() - startedAt });
    await logTelemetry({
      alias: OTOMODE_ID, model: modelId, status: 502, stream,
      latencyMs: Date.now() - startedAt, promptChars, completionChars: 0,
      promptPreview, responsePreview: "", error: `otomode attempt failed: ${detail}`,
      source: opts.source, keyId, keyName,
    });
  };

  const otomodeMeta = (servedBy: string) => ({
    route: OTOMODE_ID,
    targetModel: servedBy,
    systemPrefixApplied: false,
    latencyMs: Date.now() - startedAt,
    otomode: {
      provider: plan.provider,
      servedBy,
      attempts: attempts.map((a) => ({ model: a.model, detail: a.detail, ms: a.ms })),
      chain: chainIds,
      fallbackUsed: attempts.length > 0,
    },
  });

  for (const candidate of plan.chain) {
    // --------------------- attempt: open upstream call -----------------------
    let upstream: unknown;
    try {
      upstream = await zai.chat.completions.create({
        model: candidate.id,
        messages: prepared.map((m) => ({ role: m.role, content: m.content })),
        stream: opts.stream,
        thinking: { type: "disabled" },
        ...(opts.temperature !== undefined ? { temperature: opts.temperature } : {}),
        ...(opts.maxTokens !== undefined ? { max_tokens: opts.maxTokens } : {}),
      });
    } catch (err) {
      await recordFailure(candidate.id, err instanceof Error ? err.message : "upstream call failed", opts.stream);
      continue;
    }

    // --------------------- non-streaming: content check ----------------------
    if (!opts.stream) {
      const content: string = upstream?.choices?.[0]?.message?.content ?? "";
      if (content.trim()) {
        await logTelemetry({
          alias: OTOMODE_ID, model: candidate.id, status: 200, stream: false,
          latencyMs: Date.now() - startedAt, promptChars, completionChars: content.length,
          promptPreview, responsePreview: content, source: opts.source, keyId, keyName,
        });
        return Response.json({
          id: makeCompletionId(),
          object: "chat.completion",
          created,
          model: OTOMODE_ID,
          choices: [{ index: 0, message: { role: "assistant", content }, finish_reason: "stop" }],
          usage: {
            prompt_tokens: estimateTokens(String(promptChars / 4)),
            completion_tokens: estimateTokens(content),
            total_tokens: estimateTokens(String(promptChars / 4)) + estimateTokens(content),
          },
          devgateway: otomodeMeta(candidate.id),
        });
      }
      await recordFailure(candidate.id, "upstream returned empty content", false);
      continue;
    }

    // Backend may answer JSON despite stream:true — accept it as a valid serve.
    if (!(upstream instanceof ReadableStream)) {
      const content: string = upstream?.choices?.[0]?.message?.content ?? "";
      if (content.trim()) {
        await logTelemetry({
          alias: OTOMODE_ID, model: candidate.id, status: 200, stream: false,
          latencyMs: Date.now() - startedAt, promptChars, completionChars: content.length,
          promptPreview, responsePreview: content, source: opts.source, keyId, keyName,
        });
        return Response.json({
          id: makeCompletionId(),
          object: "chat.completion",
          created,
          model: OTOMODE_ID,
          choices: [{ index: 0, message: { role: "assistant", content }, finish_reason: "stop" }],
          usage: {
            prompt_tokens: estimateTokens(String(promptChars / 4)),
            completion_tokens: estimateTokens(content),
            total_tokens: estimateTokens(String(promptChars / 4)) + estimateTokens(content),
          },
          devgateway: otomodeMeta(candidate.id),
        });
      }
      await recordFailure(candidate.id, "upstream returned empty JSON content", true);
      continue;
    }

    // ------------------ probe: verify first content chunk --------------------
    const probe = await probeUpstreamStream(upstream);
    if (!probe.ok) {
      await recordFailure(candidate.id, probe.detail, true);
      continue;
    }

    // -------------------------- commit: serve it -----------------------------
    const completionId = makeCompletionId();
    const transformer = createSSETransformer({
      completionId,
      alias: OTOMODE_ID,
      created,
      promptChars,
      onDone: (fullText) => {
        void logTelemetry({
          alias: OTOMODE_ID, model: candidate.id, status: 200, stream: true,
          latencyMs: Date.now() - startedAt, promptChars, completionChars: fullText.length,
          promptPreview, responsePreview: fullText, source: opts.source, keyId, keyName,
        });
      },
      onError: (message) => {
        void logTelemetry({
          alias: OTOMODE_ID, model: candidate.id, status: 502, stream: true,
          latencyMs: Date.now() - startedAt, promptChars, completionChars: 0,
          promptPreview, responsePreview: "", error: `mid-stream failure after commit: ${message}`,
          source: opts.source, keyId, keyName,
        });
      },
    });

    const stream = replayProbedStream(probe, transformer);
    return new Response(stream, {
      status: 200,
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
        "X-Devgateway-Route": OTOMODE_ID,
        "X-Devgateway-Target": candidate.id,
        "X-Otomode-Served-By": candidate.id,
        "X-Otomode-Chain": chainIds.join("|"),
        "X-Otomode-Attempts": String(attempts.length + 1),
        "X-Devgateway-Ttfb-Ms": String(Date.now() - startedAt),
      },
    });
  }

  // --------------------------- every model failed ----------------------------
  const summary = attempts.map((a) => `${a.model} (${a.detail})`).join("; ") || "no attempts recorded";
  await logTelemetry({
    alias: OTOMODE_ID, model: "none", status: 502, stream: opts.stream,
    latencyMs: Date.now() - startedAt, promptChars, completionChars: 0,
    promptPreview, responsePreview: "", error: `all free models failed: ${summary}`,
    source: opts.source, keyId, keyName,
  });
  return openAIError(
    502,
    `Otomode: all ${plan.chain.length} free models failed — ${summary}`,
    "api_error"
  );
}
