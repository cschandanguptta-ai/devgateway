// Shared client-side types + fetch helpers for the gateway dashboard.

export interface RouteT {
  id: string;
  alias: string;
  targetModel: string;
  systemPrefix: string;
  description: string;
  enabled: boolean;
  usageCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface ApiKeyT {
  id: string;
  name: string;
  key: string;
  enabled: boolean;
  requestCount: number;
  lastUsedAt: string | null;
  createdAt: string;
}

export interface LogT {
  id: string;
  endpoint: string;
  alias: string;
  model: string;
  keyName: string;
  status: number;
  stream: boolean;
  latencyMs: number;
  promptChars: number;
  completionChars: number;
  promptPreview: string;
  responsePreview: string;
  error: string | null;
  source: string;
  createdAt: string;
}

export interface StatsT {
  totalRequests: number;
  okRequests: number;
  successRate: number;
  avgLatencyMs: number;
  routeCount: number;
  activeRoutes: number;
  keyCount: number;
  activeKeys: number;
  estTotalTokens: number;
  byHour: { hour: string; count: number }[];
}

export async function apiGet<T>(url: string): Promise<T> {
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) throw new Error(`GET ${url} failed: ${res.status}`);
  return res.json() as Promise<T>;
}

export async function apiSend<T>(url: string, method: "POST" | "PATCH" | "DELETE", body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: body !== undefined ? { "Content-Type": "application/json" } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string })?.error || `${method} ${url} failed: ${res.status}`);
  return data as T;
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}
