// ---------------------------------------------------------------------------
// Model Registry — source of truth for provider models & tiers.
//
// Otomode queries this registry dynamically (per request) to build the
// intra-provider smart-fallback chain: "all free models belonging to that
// specific provider". Entries can be added/edited here without touching the
// gateway pipeline — the chain adapts automatically on the next request.
// ---------------------------------------------------------------------------

export const OTOMODE_ID = "otomode";
export const OTOMODE_NAME = "Otomode";

export type ProviderId = "zai";
export type ModelTier = "free" | "paid";
export type SpeedTier = "fast" | "balanced" | "powerful";

export interface RegistryModel {
  id: string; // model identity sent to the provider SDK
  name: string; // human display name
  provider: ProviderId;
  tier: ModelTier;
  enabled: boolean;
  /** Lower = higher preference inside the Otomode fallback chain. */
  priority: number;
  contextWindow: number;
  speedTier: SpeedTier;
  description: string;
}

export const MODEL_REGISTRY: RegistryModel[] = [
  {
    id: "glm-4.6",
    name: "GLM-4.6",
    provider: "zai",
    tier: "free",
    enabled: true,
    priority: 10,
    contextWindow: 200000,
    speedTier: "powerful",
    description: "Flagship model — best reasoning and coding quality. First pick in the chain.",
  },
  {
    id: "glm-4.5-air",
    name: "GLM-4.5-Air",
    provider: "zai",
    tier: "free",
    enabled: true,
    priority: 20,
    contextWindow: 128000,
    speedTier: "balanced",
    description: "Lightweight mid-size model balancing quality and latency. Second pick.",
  },
  {
    id: "glm-4.5-flash",
    name: "GLM-4.5-Flash",
    provider: "zai",
    tier: "free",
    enabled: true,
    priority: 30,
    contextWindow: 128000,
    speedTier: "fast",
    description: "Fastest free model — final safety net of the fallback chain.",
  },
  {
    id: "glm-4.5v",
    name: "GLM-4.5V",
    provider: "zai",
    tier: "paid",
    enabled: false,
    priority: 90,
    contextWindow: 64000,
    speedTier: "balanced",
    description: "Premium vision model — paid tier, excluded from the free Otomode chain.",
  },
];

/** All enabled models registered for a provider. */
export function getModelsByProvider(provider: ProviderId): RegistryModel[] {
  return MODEL_REGISTRY.filter((m) => m.provider === provider && m.enabled);
}

/**
 * The dynamic Otomode query: every FREE model belonging to the provider,
 * pre-ordered by registry priority (re-ranked with live health data at
 * request time by buildOtomodePlan).
 */
export function getFreeModelsByProvider(provider: ProviderId): RegistryModel[] {
  return getModelsByProvider(provider)
    .filter((m) => m.tier === "free")
    .sort((a, b) => a.priority - b.priority);
}

export function getRegistryModel(id: string): RegistryModel | undefined {
  return MODEL_REGISTRY.find((m) => m.id === id);
}
