import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import type { ApiKey } from "@prisma/client";
import { getRegistryModel, OTOMODE_ID } from "@/lib/model-registry";

export { db };

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface GatewayMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface RunOptions {
  messages: GatewayMessage[];
  alias: string; // requested model name (may be an alias)
  apiKeyRecord: ApiKey | null; // null => playground bypass
  source: "api" | "playground";
  stream: boolean;
  temperature?: number;
  maxTokens?: number;
}

// ---------------------------------------------------------------------------
// Seeding — the model catalog is native (model registry: otomode + GLM models).
// Routes are optional custom overrides only; the devgateway-default catch-all
// serves any unknown model name.
// ---------------------------------------------------------------------------

const DEFAULT_ROUTES = [
  { alias: "devgateway-default", targetModel: "glm-4.6", systemPrefix: "", description: "Catch-all default route for unknown model names" },
];

const MASTER_KEY = "sk-devgw-master-key";

let seedPromise: Promise<void> | null = null;

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      const routeCount = await db.route.count();
      if (routeCount === 0) {
        await db.route.createMany({ data: DEFAULT_ROUTES });
      }
      const keyCount = await db.apiKey.count();
      if (keyCount === 0) {
        await db.apiKey.create({
          data: { name: "Default IDE Key", key: MASTER_KEY },
        });
      }
    })().catch((err) => {
      seedPromise = null;
      throw err;
    });
  }
  return seedPromise;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

export function openAIError(status: number, message: string, type = "invalid_request_error") {
  return Response.json(
    { error: { message, type, code: type === "authentication_error" ? "invalid_api_key" : null } },
    { status }
  );
}

export function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}

function resolveAlias(model: string | undefined | null): string {
  return (model && model.trim()) || "devgateway-default";
}

export interface ResolvedTarget {
  kind: "registry" | "route";
  /** model identity sent to the provider */
  targetModel: string;
  systemPrefix: string;
  /** name the request is served under — unknown names are NOT kept:
   *  they are served by the devgateway-default catch-all and reported as such */
  wireAlias: string;
  /** DB route id when served via a custom route; null for registry models */
  routeId: string | null;
  fallbackUsed: boolean;
}

/**
 * Model resolution order (no alias mapping layer — the catalog is native):
 * 1. native registry models (glm-4.6, glm-4.5-air, glm-4.5-flash) — served directly
 * 2. explicit custom routes (optional system-prefix overrides)
 * 3. devgateway-default catch-all for unknown names
 */
export async function resolveModelTarget(alias: string): Promise<ResolvedTarget | null> {
  const reg = getRegistryModel(alias);
  if (reg && reg.enabled) {
    return { kind: "registry", targetModel: reg.id, systemPrefix: "", wireAlias: reg.id, routeId: null, fallbackUsed: false };
  }
  const route = await db.route.findUnique({ where: { alias } });
  if (route && route.enabled) {
    return { kind: "route", targetModel: route.targetModel, systemPrefix: route.systemPrefix, wireAlias: route.alias, routeId: route.id, fallbackUsed: false };
  }
  const fallback = await db.route.findFirst({ where: { alias: "devgateway-default", enabled: true } });
  if (fallback) {
    return { kind: "route", targetModel: fallback.targetModel, systemPrefix: fallback.systemPrefix, wireAlias: fallback.alias, routeId: fallback.id, fallbackUsed: true };
  }
  return null;
}

export async function authenticate(authHeader: string | null): Promise<
  { ok: true; key: ApiKey } | { ok: false; response: Response }
> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return {
      ok: false,
      response: openAIError(401, "Missing API key. Pass it as `Authorization: Bearer sk-devgw-...`", "authentication_error"),
    };
  }
  const rawKey = authHeader.slice(7).trim();
  const keyRecord = await db.apiKey.findUnique({ where: { key: rawKey } });
  if (!keyRecord || !keyRecord.enabled) {
    return {
      ok: false,
      response: openAIError(401, `Invalid or disabled API key: ${rawKey.slice(0, 12)}...`, "authentication_error"),
    };
  }
  return { ok: true, key: keyRecord };
}

// ---------------------------------------------------------------------------
// Core completion logic
// ---------------------------------------------------------------------------

export function buildMessages(messages: GatewayMessage[], systemPrefix: string): GatewayMessage[] {
  const out: GatewayMessage[] = [];
  const prefix = systemPrefix.trim();
  if (prefix) out.push({ role: "system", content: prefix });
  for (const m of messages) {
    if (m && (m.role === "system" || m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim()) {
      out.push({ role: m.role, content: m.content });
    }
  }
  if (out.length === 0) out.push({ role: "user", content: "Hello" });
  return out;
}

export function makeCompletionId(): string {
  return `chatcmpl-devgw-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export async function logTelemetry(entry: {
  alias: string;
  model: string;
  status: number;
  stream: boolean;
  latencyMs: number;
  promptChars: number;
  completionChars: number;
  promptPreview: string;
  responsePreview: string;
  error?: string;
  source: "api" | "playground";
  routeId?: string | null;
  keyId?: string | null;
  keyName: string;
}) {
  try {
    await db.requestLog.create({
      data: {
        endpoint: "/v1/chat/completions",
        alias: entry.alias,
        model: entry.model,
        keyName: entry.keyName,
        status: entry.status,
        stream: entry.stream,
        latencyMs: entry.latencyMs,
        promptChars: entry.promptChars,
        completionChars: entry.completionChars,
        promptPreview: entry.promptPreview.slice(0, 500),
        responsePreview: entry.responsePreview.slice(0, 500),
        error: entry.error ?? null,
        source: entry.source,
        routeId: entry.routeId ?? null,
        keyId: entry.keyId ?? null,
      },
    });
    if (entry.routeId) {
      await db.route
        .update({ where: { id: entry.routeId }, data: { usageCount: { increment: 1 } } })
        .catch(() => {});
    }
    if (entry.keyId) {
      await db.apiKey
        .update({ where: { id: entry.keyId }, data: { requestCount: { increment: 1 }, lastUsedAt: new Date() } })
        .catch(() => {});
    }
  } catch (err) {
    console.error("[gateway] telemetry write failed:", err);
  }
}

export function lastUserPreview(messages: GatewayMessage[]): string {
  const lastUser = [...messages].reverse().find((m) => m.role === "user");
  return lastUser ? lastUser.content : messages.map((m) => m.content).join(" ");
}

/**
 * Normalizes the SDK SSE stream into strict OpenAI wire format,
 * tapping the chunks to accumulate the completion for telemetry.
 */
export function createSSETransformer(params: {
  completionId: string;
  alias: string;
  created: number;
  promptChars: number;
  onDone: (fullText: string) => void;
  onError: (message: string) => void;
}): TransformStream<Uint8Array, Uint8Array> {
  const { completionId, alias, created, promptChars, onDone, onError } = params;
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  let fullText = "";
  let finished = false;

  const emitChunk = (controller: TransformStreamDefaultController<Uint8Array>, delta: Record<string, unknown>, finishReason: string | null) => {
    const payload = {
      id: completionId,
      object: "chat.completion.chunk",
      created,
      model: alias,
      choices: [{ index: 0, delta, finish_reason: finishReason }],
    };
    controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
  };

  const finalize = (controller: TransformStreamDefaultController<Uint8Array>) => {
    if (finished) return;
    finished = true;
    try {
      emitChunk(controller, {}, "stop");
      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
    } catch {
      /* controller may already be closed when client disconnects */
    }
    onDone(fullText);
  };

  return new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      buffer += decoder.decode(chunk, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const dataStr = trimmed.slice(5).trim();
        if (!dataStr) continue;
        if (dataStr === "[DONE]") continue;
        try {
          const parsed = JSON.parse(dataStr);
          if (parsed?.error) {
            onError(parsed.error?.message || "Upstream error");
            continue;
          }
          const choice = parsed?.choices?.[0];
          if (!choice) continue;
          const deltaContent: string | undefined = choice.delta?.content ?? choice.message?.content ?? choice.text;
          if (typeof deltaContent === "string" && deltaContent) {
            fullText += deltaContent;
            emitChunk(controller, { content: deltaContent }, null);
          }
        } catch {
          /* ignore malformed line */
        }
      }
    },
    flush(controller) {
      finalize(controller);
    },
  });
}

/**
 * Runs a chat completion through the gateway (the agent runner):
 * 0. intercepts the synthetic "otomode" model -> intra-provider smart fallback
 * 1. resolves alias -> route (system prefix injection); unknown models are
 *    served by the devgateway-default catch-all and reported under its name
 * 2. calls the LLM via z-ai-web-dev-sdk (server-side) with the resolved target
 * 3. returns OpenAI-compatible streaming (SSE) or JSON response
 * 4. writes telemetry
 */
export async function runChatCompletion(opts: RunOptions): Promise<Response> {
  const startedAt = Date.now();
  const alias = resolveAlias(opts.alias);

  // ---- Otomode interception: synthetic model with dynamic free-model fallback
  if (alias === OTOMODE_ID) {
    const { runOtomodeCompletion } = await import("./otomode");
    return runOtomodeCompletion(opts);
  }

  const target = await resolveModelTarget(alias);

  if (!target) {
    return openAIError(404, `Model '${alias}' has no enabled route in the gateway and is not a registered model.`, "invalid_request_error");
  }
  const wireAlias = target.wireAlias; // served name (original unknown names are not kept)

  const prepared = buildMessages(opts.messages, target.systemPrefix);
  const promptChars = prepared.reduce((acc, m) => acc + m.content.length, 0);
  const promptPreview = lastUserPreview(prepared);
  const completionId = makeCompletionId();
  const created = Math.floor(Date.now() / 1000);

  try {
    const zai = await ZAI.create();
    const sdkStream = await zai.chat.completions.create({
      model: target.targetModel, // resolved target: registry model or custom route
      messages: prepared.map((m) => ({ role: m.role, content: m.content })),
      stream: opts.stream,
      thinking: { type: "disabled" },
      ...(opts.temperature !== undefined ? { temperature: opts.temperature } : {}),
      ...(opts.maxTokens !== undefined ? { max_tokens: opts.maxTokens } : {}),
    });

    // ----------------------------- Streaming -----------------------------
    if (opts.stream) {
      if (!(sdkStream instanceof ReadableStream)) {
        // Backend ignored stream flag — fall back to JSON response.
        const content: string = sdkStream?.choices?.[0]?.message?.content ?? "";
        await logTelemetry({
          alias: wireAlias, model: target.targetModel, status: 200, stream: false,
          latencyMs: Date.now() - startedAt, promptChars, completionChars: content.length,
          promptPreview, responsePreview: content, source: opts.source,
          routeId: target.routeId, keyId: opts.apiKeyRecord?.id ?? null, keyName: opts.apiKeyRecord?.name ?? "Playground",
        });
        return Response.json({
          id: completionId, object: "chat.completion", created, model: wireAlias,
          choices: [{ index: 0, message: { role: "assistant", content }, finish_reason: "stop" }],
          usage: { prompt_tokens: estimateTokens(String(promptChars / 4)), completion_tokens: estimateTokens(content), total_tokens: estimateTokens(String(promptChars / 4)) + estimateTokens(content) },
        });
      }

      const latencyAtStart = Date.now() - startedAt;
      const transformer = createSSETransformer({
        completionId, alias: wireAlias, created, promptChars,
        onDone: (fullText) => {
          void logTelemetry({
            alias: wireAlias, model: target.targetModel, status: 200, stream: true,
            latencyMs: Date.now() - startedAt, promptChars, completionChars: fullText.length,
            promptPreview, responsePreview: fullText, source: opts.source,
            routeId: target.routeId, keyId: opts.apiKeyRecord?.id ?? null, keyName: opts.apiKeyRecord?.name ?? "Playground",
          });
        },
        onError: (message) => {
          void logTelemetry({
            alias: wireAlias, model: target.targetModel, status: 502, stream: true,
            latencyMs: Date.now() - startedAt, promptChars, completionChars: 0,
            promptPreview, responsePreview: "", error: message, source: opts.source,
            routeId: target.routeId, keyId: opts.apiKeyRecord?.id ?? null, keyName: opts.apiKeyRecord?.name ?? "Playground",
          });
        },
      });

      const stream = sdkStream.pipeThrough(transformer);
      return new Response(stream, {
        status: 200,
        headers: {
          "Content-Type": "text/event-stream; charset=utf-8",
          "Cache-Control": "no-cache, no-transform",
          Connection: "keep-alive",
          "X-Accel-Buffering": "no",
          "X-Devgateway-Route": wireAlias,
          "X-Devgateway-Target": target.targetModel,
          "X-Devgateway-Alias-Fallback": target.fallbackUsed ? "true" : "false",
          "X-Devgateway-Ttfb-Ms": String(latencyAtStart),
        },
      });
    }

    // --------------------------- Non-streaming ---------------------------
    const content: string = sdkStream?.choices?.[0]?.message?.content ?? "";
    const latencyMs = Date.now() - startedAt;
    await logTelemetry({
      alias: wireAlias, model: target.targetModel, status: 200, stream: false,
      latencyMs, promptChars, completionChars: content.length,
      promptPreview, responsePreview: content, source: opts.source,
      routeId: target.routeId, keyId: opts.apiKeyRecord?.id ?? null, keyName: opts.apiKeyRecord?.name ?? "Playground",
    });
    const pt = estimateTokens(String(promptChars / 4));
    const ct = estimateTokens(content);
    return Response.json({
      id: completionId, object: "chat.completion", created, model: wireAlias,
      choices: [{ index: 0, message: { role: "assistant", content }, finish_reason: "stop" }],
      usage: { prompt_tokens: pt, completion_tokens: ct, total_tokens: pt + ct },
      devgateway: { route: wireAlias, targetModel: target.targetModel, systemPrefixApplied: Boolean(target.systemPrefix.trim()), aliasFallbackUsed: target.fallbackUsed, latencyMs },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown gateway error";
    const latencyMs = Date.now() - startedAt;
    await logTelemetry({
      alias: wireAlias, model: target.targetModel, status: 502, stream: opts.stream,
      latencyMs, promptChars, completionChars: 0,
      promptPreview, responsePreview: "", error: message, source: opts.source,
      routeId: target.routeId, keyId: opts.apiKeyRecord?.id ?? null, keyName: opts.apiKeyRecord?.name ?? "Playground",
    });
    return openAIError(502, `Upstream LLM error: ${message}`, "api_error");
  }
}
