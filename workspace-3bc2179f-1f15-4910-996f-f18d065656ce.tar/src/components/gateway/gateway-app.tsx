"use client";

import { useCallback, useEffect, useState } from "react";
import { Cloud, Activity, GitFork, KeyRound, Code2, BarChart3, MessageSquare, LayoutDashboard } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OverviewTab } from "./overview-tab";
import { PlaygroundTab } from "./playground-tab";
import { RoutesTab } from "./routes-tab";
import { KeysTab } from "./keys-tab";
import { IdeConfigTab } from "./ide-config-tab";
import { TelemetryTab } from "./telemetry-tab";
import { apiGet, type RouteT, type ApiKeyT, type LogT, type StatsT } from "@/lib/gateway-client";

export type RefreshFn = () => void;

export function GatewayApp() {
  const [activeTab, setActiveTab] = useState("overview");
  const [routes, setRoutes] = useState<RouteT[]>([]);
  const [keys, setKeys] = useState<ApiKeyT[]>([]);
  const [logs, setLogs] = useState<LogT[]>([]);
  const [stats, setStats] = useState<StatsT | null>(null);
  const [loaded, setLoaded] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const [r, k, l, s] = await Promise.all([
        apiGet<{ routes: RouteT[] }>("/api/admin/routes"),
        apiGet<{ keys: ApiKeyT[] }>("/api/admin/keys"),
        apiGet<{ logs: LogT[] }>("/api/admin/logs?limit=100"),
        apiGet<StatsT>("/api/admin/stats"),
      ]);
      setRoutes(r.routes);
      setKeys(k.keys);
      setLogs(l.logs);
      setStats(s);
    } catch (err) {
      console.error("Dashboard refresh failed:", err);
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const interval = setInterval(() => void refresh(), 15000);
    return () => clearInterval(interval);
  }, [refresh]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur sticky top-0 z-40 px-4 sm:px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center space-x-3 min-w-0">
            <div className="bg-primary p-2 rounded-xl text-primary-foreground shadow-lg shadow-primary/25 shrink-0">
              <Cloud className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h1 className="font-bold text-base sm:text-lg leading-tight flex items-center gap-2 truncate">
                DevGateway AI Hub
                <span className="hidden sm:inline text-[10px] font-normal bg-primary/10 text-primary px-2 py-0.5 rounded-full border border-primary/25 whitespace-nowrap">
                  v6.0 Server Edition
                </span>
              </h1>
              <p className="text-[11px] sm:text-xs text-muted-foreground truncate">
                OpenAI-compatible gateway · model routing · virtual keys · live telemetry
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="relative flex h-2.5 w-2.5 text-emerald-400">
              <span className="devgw-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400" />
            </span>
            <span className="text-xs font-mono text-emerald-400 hidden sm:inline">Gateway Online</span>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="border-b bg-background/60">
          <TabsList className="max-w-7xl mx-auto w-full justify-start rounded-none bg-transparent h-auto p-0 px-0 gap-0 overflow-x-auto flex-nowrap sm:px-6">
            {[
              { id: "overview", label: "Overview", icon: LayoutDashboard },
              { id: "playground", label: "Playground", icon: MessageSquare },
              { id: "routes", label: "Model Router", icon: GitFork },
              { id: "keys", label: "API Keys", icon: KeyRound },
              { id: "ide", label: "IDE Config", icon: Code2 },
              { id: "telemetry", label: "Telemetry", icon: BarChart3 },
            ].map((t) => (
              <TabsTrigger
                key={t.id}
                value={t.id}
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary text-muted-foreground px-3 sm:px-4 py-3 gap-1.5 whitespace-nowrap text-xs sm:text-sm"
              >
                <t.icon className="h-4 w-4 shrink-0" />
                <span>{t.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <main className="flex-1 w-full max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
          <TabsContent value="overview" className="mt-0 space-y-6">
            <OverviewTab stats={stats} routes={routes} logs={logs} loaded={loaded} onGoTab={setActiveTab} refresh={refresh} />
          </TabsContent>
          <TabsContent value="playground" className="mt-0">
            <PlaygroundTab routes={routes} onActivity={refresh} />
          </TabsContent>
          <TabsContent value="routes" className="mt-0">
            <RoutesTab routes={routes} refresh={refresh} />
          </TabsContent>
          <TabsContent value="keys" className="mt-0">
            <KeysTab keys={keys} refresh={refresh} />
          </TabsContent>
          <TabsContent value="ide" className="mt-0">
            <IdeConfigTab routes={routes} keys={keys} />
          </TabsContent>
          <TabsContent value="telemetry" className="mt-0">
            <TelemetryTab logs={logs} stats={stats} refresh={refresh} />
          </TabsContent>
        </main>
      </Tabs>

      {/* Footer (sticks to bottom via flex + mt-auto) */}
      <footer className="mt-auto border-t bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col sm:flex-row items-center justify-between gap-1 text-[11px] text-muted-foreground">
          <span>DevGateway AI Hub v6.0 — rebuilt from the Gemini Canvas proxy into a real server-side gateway</span>
          <span className="font-mono">POST /api/v1/chat/completions · z-ai-web-dev-sdk · Next.js 16</span>
        </div>
      </footer>
    </div>
  );
}
