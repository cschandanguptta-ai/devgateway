"use client";

import { useState } from "react";
import { KeyRound, Plus, Copy, Trash2, Eye, EyeOff } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { apiSend, timeAgo, type ApiKeyT } from "@/lib/gateway-client";

function maskKey(key: string): string {
  if (key.length <= 14) return key.slice(0, 8) + "…";
  return `${key.slice(0, 11)}…${key.slice(-4)}`;
}

export function KeysTab({ keys, refresh }: { keys: ApiKeyT[]; refresh: () => void }) {
  const [genOpen, setGenOpen] = useState(false);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});

  const generate = async () => {
    setBusy(true);
    try {
      const res = await apiSend<{ key: ApiKeyT }>("/api/admin/keys", "POST", { name });
      toast.success(`Key '${res.key.name}' generated`, { description: "Copy it now — it is always visible in this table." });
      setGenOpen(false);
      setName("");
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to generate key");
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (k: ApiKeyT) => {
    try {
      await apiSend(`/api/admin/keys/${k.id}`, "PATCH", { enabled: !k.enabled });
      toast.success(`${k.name} ${k.enabled ? "disabled" : "enabled"}`);
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to toggle key");
    }
  };

  const remove = async (k: ApiKeyT) => {
    try {
      await apiSend(`/api/admin/keys/${k.id}`, "DELETE");
      toast.success(`Key '${k.name}' revoked`);
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to revoke key");
    }
  };

  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(label);
    } catch {
      toast.error("Clipboard unavailable — select the text manually");
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <KeyRound className="h-4 w-4 text-primary" /> Virtual API Keys
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              IDEs authenticate with <code className="font-mono">Authorization: Bearer &lt;key&gt;</code>. Usage per key is tracked in telemetry.
            </CardDescription>
          </div>
          <Dialog open={genOpen} onOpenChange={setGenOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Generate Key
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Generate a virtual key</DialogTitle>
                <DialogDescription>Keys are prefixed with <span className="font-mono">sk-devgw-</span> and can be revoked anytime.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-1.5">
                  <Label htmlFor="key-name">Key name</Label>
                  <Input id="key-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Cursor on MacBook" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setGenOpen(false)}>Cancel</Button>
                <Button onClick={() => void generate()} disabled={busy}>Generate</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent className="space-y-3">
          {keys.length === 0 ? (
            <div className="text-sm text-muted-foreground py-10 text-center border border-dashed rounded-lg">
              No keys yet. Generate one to authenticate IDE clients.
            </div>
          ) : (
            keys.map((k) => (
              <div key={k.id} className={`flex flex-col sm:flex-row sm:items-center gap-3 p-3.5 rounded-xl border bg-background/50 ${k.enabled ? "" : "opacity-50"}`}>
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold">{k.name}</span>
                    {k.name === "Default IDE Key" && <Badge variant="secondary" className="text-[9px]">seeded</Badge>}
                    {!k.enabled && <Badge variant="destructive" className="text-[9px]">disabled</Badge>}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <code className="text-xs font-mono text-amber-300 bg-background border rounded px-2 py-0.5 truncate max-w-[280px]">
                      {revealed[k.id] ? k.key : maskKey(k.key)}
                    </code>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setRevealed((p) => ({ ...p, [k.id]: !p[k.id] }))} aria-label="Toggle reveal key">
                      {revealed[k.id] ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => void copy(k.key, "API key copied!")} aria-label="Copy key">
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0 justify-between sm:justify-end">
                  <div className="text-right">
                    <div className="text-[11px] font-mono text-muted-foreground">{k.requestCount} calls</div>
                    <div className="text-[10px] text-muted-foreground/70">{k.lastUsedAt ? `last used ${timeAgo(k.lastUsedAt)}` : "never used"}</div>
                  </div>
                  <Switch checked={k.enabled} onCheckedChange={() => void toggle(k)} aria-label={`Toggle ${k.name}`} />
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" aria-label={`Revoke ${k.name}`}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Revoke &apos;{k.name}&apos;?</AlertDialogTitle>
                        <AlertDialogDescription>Clients using this key will receive 401 errors immediately.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => void remove(k)}>Revoke</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
