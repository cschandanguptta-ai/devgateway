"use client";

import { Activity, GitFork, KeyRound, Zap, ArrowRight, Terminal } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { timeAgo, type RouteT, type LogT, type StatsT } from "@/lib/gateway-client";

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  sub: string;
  tone: "blue" | "green" | "amber" | "violet";
}) {
  const tones: Record<string, string> = {
    blue: "bg-primary/10 text-primary border-primary/25",
    green: "bg-emerald-500/10 text-emerald-400 border-emerald-500/25",
    amber: "bg-amber-500/10 text-amber-400 border-amber-500/25",
    violet: "bg-violet-500/10 text-violet-400 border-violet-500/25",
  };
  return (
    <Card className="gap-2">
      <CardHeader className="pb-0">
        <div className="flex items-center justify-between">
          <CardDescription className="text-xs font-medium uppercase tracking-wider">{label}</CardDescription>
          <div className={`p-1.5 rounded-lg border ${tones[tone]}`}>
            <Icon className="h-4 w-4" />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold font-mono">{value}</div>
        <p className="text-[11px] text-muted-foreground mt-1">{sub}</p>
      </CardContent>
    </Card>
  );
}

export function OverviewTab({
  stats,
  routes,
  logs,
  loaded,
  onGoTab,
  refresh,
}: {
  stats: StatsT | null;
  routes: RouteT[];
  logs: LogT[];
  loaded: boolean;
  onGoTab: (tab: string) => void;
  refresh: () => void;
}) {
  const maxHour = Math.max(1, ...(stats?.byHour?.map((h) => h.count) ?? [1]));
  const activeRoutes = routes.filter((r) => r.enabled);

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className="border-primary/20 bg-gradient-to-r from-primary/10 via-card to-card">
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <CardTitle className="text-lg sm:text-xl">Server-Side Gateway Engine</CardTitle>
              <CardDescription className="text-sm leading-relaxed mt-1.5 max-w-3xl">
                The original hub polled an ngrok tunnel from the browser and relayed tokens back by hand. This rebuild runs the
                entire pipeline on the server: IDE clients call <code className="font-mono text-xs text-primary">POST /api/v1/chat/completions</code>,
                the gateway authenticates a virtual key, resolves the model natively from the registry (or a custom route), injects
                any system prefix, and streams OpenAI-format SSE straight back — no tunnels, no polling.
              </CardDescription>
            </div>
            <Button onClick={() => void refresh()} variant="outline" size="sm" className="gap-1.5 shrink-0 self-start">
              <Activity className="h-3.5 w-3.5" /> Refresh
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Stat cards */}
      {!loaded || !stats ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Zap} label="Total Requests" value={String(stats.totalRequests)} sub={`${stats.okRequests} succeeded · ${stats.successRate}% success`} tone="blue" />
          <StatCard icon={Activity} label="Avg Latency" value={`${stats.avgLatencyMs} ms`} sub="rolling window of last 200 calls" tone="green" />
          <StatCard icon={GitFork} label="Custom Routes" value={`${stats.activeRoutes}/${stats.routeCount}`} sub="enabled / total overrides" tone="amber" />
          <StatCard icon={KeyRound} label="Virtual Keys" value={`${stats.activeKeys}/${stats.keyCount}`} sub={`≈ ${stats.estTotalTokens.toLocaleString()} tokens processed`} tone="violet" />
        </div>
      )}

      <div className="grid lg:grid-cols-5 gap-6">
        {/* 24h activity chart */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-base">Requests · last 24 hours</CardTitle>
            <CardDescription className="text-xs">Gateway throughput per hour (local time)</CardDescription>
          </CardHeader>
          <CardContent>
            {stats && stats.byHour.length > 0 ? (
              <div className="flex items-end gap-[3px] h-36">
                {stats.byHour.map((h) => (
                  <div key={h.hour} className="flex-1 flex flex-col items-center gap-1 group relative">
                    <div className="text-[10px] font-mono text-primary opacity-0 group-hover:opacity-100 transition-opacity">{h.count}</div>
                    <div
                      className={`w-full rounded-t-sm transition-all ${h.count > 0 ? "bg-primary/70 group-hover:bg-primary" : "bg-muted"}`}
                      style={{ height: `${Math.max(3, (h.count / maxHour) * 110)}px` }}
                    />
                    <div className="text-[8px] font-mono text-muted-foreground rotate-45 origin-top-left translate-y-1 hidden sm:block">{h.hour}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-36 flex items-center justify-center text-sm text-muted-foreground">
                No traffic yet — send your first request from the Playground.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent activity */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Recent Activity</CardTitle>
              <CardDescription className="text-xs">Latest calls through the gateway</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="gap-1 text-xs" onClick={() => onGoTab("telemetry")}>
              All <ArrowRight className="h-3 w-3" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2 max-h-72 overflow-y-auto">
            {!loaded ? (
              <Skeleton className="h-20" />
            ) : logs.length === 0 ? (
              <div className="text-sm text-muted-foreground py-8 text-center">
                No requests logged yet.
                <br />
                Try the Playground tab — it routes through the same pipeline.
              </div>
            ) : (
              logs.slice(0, 12).map((l) => (
                <div key={l.id} className="flex items-start justify-between gap-2 p-2.5 rounded-lg bg-background/60 border text-xs">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-mono font-medium text-foreground">{l.alias}</span>
                      <Badge variant={l.status === 200 ? "secondary" : "destructive"} className="h-4 px-1 text-[9px] font-mono">
                        {l.status}
                      </Badge>
                      {l.source === "playground" && <Badge variant="outline" className="h-4 px-1 text-[9px]">playground</Badge>}
                    </div>
                    <p className="text-muted-foreground truncate mt-0.5">{l.error || l.responsePreview || "—"}</p>
                  </div>
                  <div className="text-right shrink-0 space-y-0.5">
                    <div className="font-mono text-muted-foreground">{l.latencyMs}ms</div>
                    <div className="text-[10px] text-muted-foreground/70">{timeAgo(l.createdAt)}</div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick start */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Terminal className="h-4 w-4 text-primary" /> Quick Start — point any OpenAI SDK at the gateway
          </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">1. Grab a virtual key</p>
            <p className="text-sm text-muted-foreground">
              Keys live in the API Keys tab. The seeded master key is <code className="font-mono text-xs text-amber-300">sk-devgw-master-key</code>.
              Generate per-client keys to track usage independently.
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">2. Call the gateway</p>
            <pre className="text-[11px] font-mono bg-background rounded-lg p-3 border overflow-x-auto leading-relaxed">
{`curl $BASE_URL/api/v1/chat/completions \\
  -H "Authorization: Bearer sk-devgw-master-key" \\
  -H "Content-Type: application/json" \\
  -d '{"model":"gpt-4o","messages":[{"role":"user","content":"Hello"}]}'`}
            </pre>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
