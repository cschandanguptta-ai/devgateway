"use client";

import { useEffect, useState } from "react";
import { Code2, Copy, Check, Monitor, TerminalSquare, Braces } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import type { RouteT, ApiKeyT } from "@/lib/gateway-client";
import { getModelsByProvider } from "@/lib/model-registry";

function CopyBlock({ title, code, lang }: { title: string; code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success(`${title} copied!`);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Clipboard unavailable");
    }
  };
  return (
    <div className="rounded-xl border bg-background overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2 border-b bg-card/60">
        <span className="text-[11px] font-mono font-semibold text-muted-foreground flex items-center gap-1.5">
          {lang === "python" ? "🐍" : lang === "ts" ? "TS" : "$"} {title}
        </span>
        <Button variant="ghost" size="sm" className="h-6 px-2 text-[11px] gap-1" onClick={copy}>
          {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
          {copied ? "Copied" : "Copy"}
        </Button>
      </div>
      <pre className="p-3.5 text-[11px] font-mono text-emerald-300/90 overflow-x-auto leading-relaxed whitespace-pre">{code}</pre>
    </div>
  );
}

export function IdeConfigTab({ routes, keys }: { routes: RouteT[]; keys: ApiKeyT[] }) {
  // TabsContent only mounts on client interaction, so window is available here.
  const [origin] = useState(() => (typeof window !== "undefined" ? window.location.origin : ""));
  const [manualKey, setManualKey] = useState<string | null>(null);
  const selectedKey = manualKey || keys[0]?.key || "sk-devgw-master-key";

  const baseUrl = `${origin || "http://localhost:3000"}/api/v1`;
  // Native catalog: Otomode (synthetic smart fallback) first, then registry models
  const modelIds = ["otomode", ...getModelsByProvider("zai").map((m) => m.id)];
  const modelSample = modelIds[0] || "otomode";

  const curlCode = `curl ${baseUrl}/chat/completions \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer ${selectedKey}" \\
  -d '{
    "model": "${modelSample}",
    "stream": true,
    "messages": [
      {"role": "system", "content": "You are a senior code reviewer."},
      {"role": "user", "content": "Explain what this gateway does."}
    ]
  }'`;

  const pythonCode = `from openai import OpenAI

client = OpenAI(
    base_url="${baseUrl}",
    api_key="${selectedKey}",
)

stream = client.chat.completions.create(
    model="${modelSample}",  # otomode = smart fallback, or a fixed glm model
    messages=[{"role": "user", "content": "Hello from my IDE!"}],
    stream=True,
)

for chunk in stream:
    delta = chunk.choices[0].delta
    if delta.content:
        print(delta.content, end="", flush=True)`;

  const tsCode = `const res = await fetch("${baseUrl}/chat/completions", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: "Bearer ${selectedKey}",
  },
  body: JSON.stringify({
    model: "${modelSample}",
    stream: true,
    messages: [{ role: "user", content: "Hello from my IDE!" }],
  }),
});

const reader = res.body!.getReader();
const decoder = new TextDecoder();
for (;;) {
  const { done, value } = await reader.read();
  if (done) break;
  process.stdout.write(decoder.decode(value));
}`;

  const cursorConfig = `# Cursor IDE → Settings → Models
# 1. Disable all default models, then enable "OpenAI API Key"
# 2. Override OpenAI Base URL:  ${baseUrl}
# 3. API Key:                   ${selectedKey}
# 4. Add these model names under "OpenAI API Key":
${modelIds.map((m) => `#    - ${m}`).join("\n")}

# otomode = smart fallback across all free models (recommended)
# Any OpenAI-compatible tool works the same way:
#   base_url = ${baseUrl}
#   api_key  = ${selectedKey}`;

  return (
    <div className="space-y-6">
      <Card className="border-primary/20">
        <CardHeader className="pb-4">
          <CardTitle className="text-base flex items-center gap-2">
            <Monitor className="h-4 w-4 text-primary" /> Connection Endpoint
          </CardTitle>
          <CardDescription className="text-xs">
            Fully OpenAI-compatible — point any SDK, IDE or agent framework at the base URL below. Streaming (SSE) and JSON modes supported.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="rounded-lg border bg-background p-3 space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Base URL</div>
              <div className="flex items-center gap-1.5">
                <code className="text-xs font-mono text-primary truncate">{baseUrl}</code>
                <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => void navigator.clipboard.writeText(baseUrl).then(() => toast.success("Base URL copied!"))} aria-label="Copy base URL">
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <div className="rounded-lg border bg-background p-3 space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">API Key</div>
              <div className="flex items-center gap-2">
                <code className="text-xs font-mono text-amber-300 truncate">{selectedKey}</code>
                {keys.length > 1 && (
                  <select
                    className="bg-transparent text-[10px] text-muted-foreground underline cursor-pointer"
                    value={selectedKey}
                    onChange={(e) => setManualKey(e.target.value)}
                    aria-label="Choose key for snippets"
                  >
                    {keys.map((k) => (
                      <option key={k.id} value={k.key} className="bg-card text-foreground">
                        {k.name}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mr-1 self-center">Available models:</span>
            {modelIds.map((m, i) => (
              <Badge
                key={m}
                variant={i === 0 ? "default" : "secondary"}
                className="font-mono text-[10px]"
                title={i === 0 ? "Synthetic model — intra-provider smart fallback across all free models" : undefined}
              >
                {m}
              </Badge>
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground">
            <span className="font-mono">otomode</span> is a synthetic model: the gateway dynamically queries the model
            registry for all free models of the provider and streams from the first healthy one — smart intra-provider
            fallback with no fixed route. The <span className="font-mono">glm-*</span> models resolve natively from the registry.
          </p>
        </CardContent>
      </Card>

      <Tabs defaultValue="curl">
        <TabsList className="bg-card border">
          <TabsTrigger value="curl" className="gap-1.5 text-xs"><TerminalSquare className="h-3.5 w-3.5" /> curl</TabsTrigger>
          <TabsTrigger value="python" className="gap-1.5 text-xs">Python SDK</TabsTrigger>
          <TabsTrigger value="ts" className="gap-1.5 text-xs">TypeScript</TabsTrigger>
          <TabsTrigger value="cursor" className="gap-1.5 text-xs"><Braces className="h-3.5 w-3.5" /> Cursor IDE</TabsTrigger>
        </TabsList>
        <TabsContent value="curl" className="mt-3">
          <CopyBlock title="curl — streaming completion" code={curlCode} />
        </TabsContent>
        <TabsContent value="python" className="mt-3">
          <CopyBlock title="openai-python — streaming" code={pythonCode} lang="python" />
          <p className="text-[11px] text-muted-foreground mt-2">Works with any tool that speaks the OpenAI protocol: LangChain, LiteLLM, Continue.dev, aider, Cline…</p>
        </TabsContent>
        <TabsContent value="ts" className="mt-3">
          <CopyBlock title="fetch — streaming SSE" code={tsCode} lang="ts" />
        </TabsContent>
        <TabsContent value="cursor" className="mt-3">
          <CopyBlock title="Cursor IDE setup" code={cursorConfig} />
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Code2 className="h-4 w-4 text-primary" /> API surface
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 gap-2 text-xs font-mono">
            {[
              ["POST", "/api/v1/chat/completions", "OpenAI-compatible chat (SSE + JSON)"],
              ["GET", "/api/v1/models", "Model list — Otomode injected at the top"],
              ["GET", "/api/otomode", "Otomode smart-fallback chain (live)"],
              ["GET", "/api/health", "Gateway health probe"],
              ["POST", "/api/playground", "Dashboard playground (no key required)"],
            ].map(([method, path, desc]) => (
              <div key={path} className="flex items-center gap-2 rounded-lg border bg-background/50 px-3 py-2">
                <Badge variant={method === "GET" ? "secondary" : "default"} className="text-[10px] font-mono shrink-0">{method}</Badge>
                <div className="min-w-0">
                  <div className="font-mono truncate">{path}</div>
                  <div className="text-[10px] text-muted-foreground font-sans">{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
