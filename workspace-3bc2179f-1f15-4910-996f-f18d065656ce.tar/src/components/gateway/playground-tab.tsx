"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Send, Square, Bot, User, Trash2, Loader2, Sparkles, RefreshCw } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { apiGet } from "@/lib/gateway-client";
import type { RouteT } from "@/lib/gateway-client";
import { getModelsByProvider } from "@/lib/model-registry";

interface ChatMsg {
  role: "user" | "assistant";
  content: string;
  latencyMs?: number;
  servedBy?: string; // otomode: actual model that served the request
}

interface OtomodeChainEntryT {
  id: string;
  name: string;
  tier: string;
  priority: number;
  contextWindow: number;
  speedTier: string;
  description: string;
  health: { recentCalls: number; recentFails: number; failRate: number; state: "healthy" | "degraded" | "unknown" };
}

interface OtomodePlanT {
  model: string;
  name: string;
  provider: string;
  strategy: string;
  chain: OtomodeChainEntryT[];
  error?: string;
}

export const OTOMODE = "otomode";

// Native model catalog — otomode (synthetic) + provider registry models.
const AVAILABLE_MODELS = getModelsByProvider("zai");

const WELCOME: ChatMsg = {
  role: "assistant",
  content: "Welcome to the DevGateway playground. Every message here goes through the full gateway pipeline — exactly like an IDE client would. Otomode (selected by default) provides smart intra-provider fallback across all free provider models; or pick a fixed GLM model from the registry and ask something.",
};

export function PlaygroundTab({ onActivity }: { routes?: RouteT[]; onActivity: () => void }) {
  const [messages, setMessages] = useState<ChatMsg[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [alias, setAlias] = useState<string>(OTOMODE); // Otomode sits at the top of the list => default
  const [streaming, setStreaming] = useState(false);
  const [streamMode, setStreamMode] = useState(true);
  const [otomodePlan, setOtomodePlan] = useState<OtomodePlanT | null>(null);
  const [planLoading, setPlanLoading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const currentModel = AVAILABLE_MODELS.find((m) => m.id === alias);

  const fetchPlan = useCallback(() => {
    setPlanLoading(true);
    apiGet<OtomodePlanT>("/api/otomode")
      .then(setOtomodePlan)
      .catch(() => setOtomodePlan(null))
      .finally(() => setPlanLoading(false));
  }, []);

  useEffect(() => {
    if (alias === OTOMODE) fetchPlan();
  }, [alias, fetchPlan]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || streaming || !alias) return;

    const history = [...messages.filter((m) => m !== WELCOME), { role: "user" as const, content: text }];
    setMessages([...history, { role: "assistant", content: "" }]);
    setInput("");
    setStreaming(true);

    const controller = new AbortController();
    abortRef.current = controller;
    const startedAt = Date.now();

    try {
      const res = await fetch("/api/playground", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          model: alias,
          stream: streamMode,
          messages: history.map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: { message: res.statusText } }));
        throw new Error(err?.error?.message || `HTTP ${res.status}`);
      }

      // Otomode reports the actual model that served the request
      const headerServedBy = res.headers.get("X-Otomode-Served-By") ?? undefined;
      if (streamMode && res.body) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let acc = "";
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            const t = line.trim();
            if (!t.startsWith("data:")) continue;
            const dataStr = t.slice(5).trim();
            if (!dataStr || dataStr === "[DONE]") continue;
            try {
              const chunk = JSON.parse(dataStr);
              const delta = chunk?.choices?.[0]?.delta?.content;
              if (typeof delta === "string" && delta) {
                acc += delta;
                setMessages((prev) => {
                  const next = [...prev];
                  next[next.length - 1] = { role: "assistant", content: acc };
                  return next;
                });
              }
            } catch {
              /* skip malformed line */
            }
          }
        }
        setMessages((prev) => {
          const next = [...prev];
          next[next.length - 1] = { role: "assistant", content: acc || "(empty response)", latencyMs: Date.now() - startedAt, servedBy: headerServedBy };
          return next;
        });
      } else {
        const data = await res.json();
        const content = data?.choices?.[0]?.message?.content ?? "(empty response)";
        setMessages((prev) => {
          const next = [...prev];
          next[next.length - 1] = {
            role: "assistant",
            content,
            latencyMs: data?.devgateway?.latencyMs,
            servedBy: data?.devgateway?.otomode?.servedBy ?? headerServedBy,
          };
          return next;
        });
      }
      onActivity();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Request failed";
      if (message !== "AbortError") {
        setMessages((prev) => {
          const next = [...prev];
          next[next.length - 1] = { role: "assistant", content: `⚠ ${message}` };
          return next;
        });
      }
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  };

  const stop = () => {
    abortRef.current?.abort();
    setStreaming(false);
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Chat panel */}
      <Card className="lg:col-span-2 flex flex-col h-[62vh] min-h-[420px]">
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
          <div>
            <CardTitle className="text-base">Playground</CardTitle>
            <CardDescription className="text-xs">Streams through /api/playground — same pipeline as the public API</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setStreamMode(!streamMode)}
              className="text-[11px] gap-1"
              title="Toggle streaming mode"
            >
              {streamMode ? <Square className="h-3 w-3" /> : <Send className="h-3 w-3" />}
              {streamMode ? "Stream: ON" : "Stream: OFF"}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setMessages([WELCOME])} className="text-[11px] gap-1">
              <Trash2 className="h-3 w-3" /> Clear
            </Button>
          </div>
        </CardHeader>
        <Separator />
        <CardContent className="flex-1 flex flex-col p-0 min-h-0">
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-2.5 ${m.role === "user" ? "justify-end" : ""}`}>
                {m.role === "assistant" && (
                  <div className="bg-primary/15 text-primary p-1.5 rounded-lg h-fit shrink-0">
                    <Bot className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-sm whitespace-pre-wrap leading-relaxed ${
                    m.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-background border rounded-bl-sm"
                  }`}
                >
                  {m.content || (streaming && i === messages.length - 1 ? <Loader2 className="h-4 w-4 animate-spin" /> : "")}
                  {m.latencyMs !== undefined && (
                    <div className={`text-[10px] mt-1.5 font-mono ${m.role === "user" ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                      {m.servedBy && <span className="text-primary">⚡ otomode → {m.servedBy} · </span>}
                      {m.latencyMs} ms
                    </div>
                  )}
                </div>
                {m.role === "user" && (
                  <div className="bg-muted p-1.5 rounded-lg h-fit shrink-0">
                    <User className="h-4 w-4" />
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="border-t p-3 flex gap-2 items-end">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              }}
              placeholder="Ask anything… (Enter to send, Shift+Enter for newline)"
              className="min-h-[44px] max-h-32 resize-none text-sm"
              rows={1}
            />
            {streaming ? (
              <Button onClick={stop} variant="destructive" size="icon" className="h-11 w-11 shrink-0" aria-label="Stop streaming">
                <Square className="h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={() => void send()} size="icon" className="h-11 w-11 shrink-0" disabled={!input.trim() || !alias} aria-label="Send message">
                <Send className="h-4 w-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Side panel: route context */}
      <div className="space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Model Selection</CardTitle>
            <CardDescription className="text-xs">Otomode = smart fallback · GLM models resolve natively from the registry</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Select value={alias} onValueChange={setAlias}>
              <SelectTrigger className="w-full font-mono text-sm">
                <SelectValue placeholder="Pick a model" />
              </SelectTrigger>
              <SelectContent>
                {/* Synthetic Otomode model — injected at the TOP of the list */}
                <SelectItem value={OTOMODE} className="gap-2">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="h-3.5 w-3.5 text-primary" />
                    <span className="font-medium">Otomode</span>
                    <Badge variant="default" className="ml-1 h-4 rounded-sm px-1 text-[9px] uppercase tracking-wide">Smart</Badge>
                  </span>
                </SelectItem>
                <Separator className="my-1" />
                {AVAILABLE_MODELS.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    <span className="flex items-center gap-1.5">
                      {m.id}
                      <Badge variant="secondary" className="h-4 px-1 text-[9px] uppercase">{m.tier}</Badge>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {alias === OTOMODE ? (
              <div className="text-xs space-y-2.5 pt-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Mode</span>
                  <Badge variant="default" className="font-mono text-[10px] gap-1">
                    <Sparkles className="h-3 w-3" /> smart fallback
                  </Badge>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Fallback chain (live)</span>
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={fetchPlan} aria-label="Refresh fallback chain">
                    {planLoading ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                  </Button>
                </div>
                {otomodePlan?.chain?.length ? (
                  <div className="space-y-1.5">
                    {otomodePlan.chain.map((entry, idx) => (
                      <div key={entry.id} className="rounded-md border bg-background/60 px-2.5 py-2 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-[11px] flex items-center gap-1.5">
                            <span className="text-muted-foreground">#{idx + 1}</span>
                            {entry.id}
                          </span>
                          <span className="flex items-center gap-1">
                            <Badge variant="secondary" className="h-4 px-1 text-[9px] uppercase">{entry.tier}</Badge>
                            <span
                              className={`inline-block h-1.5 w-1.5 rounded-full ${
                                entry.health.state === "healthy"
                                  ? "bg-emerald-400"
                                  : entry.health.state === "degraded"
                                    ? "bg-amber-400"
                                    : "bg-muted-foreground/40"
                              }`}
                              title={`health: ${entry.health.state}`}
                            />
                          </span>
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          {entry.name} · {entry.speedTier}
                          {entry.health.recentCalls > 0 &&
                            ` · ${entry.health.recentFails}/${entry.health.recentCalls} recent fails`}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-md border bg-background/60 px-2.5 py-2 text-[11px] text-muted-foreground">
                    {planLoading ? "Resolving fallback chain…" : "No free models registered for this provider."}
                  </div>
                )}
                <p className="text-[10px] text-muted-foreground leading-relaxed pt-0.5">
                  Dynamically queries the model registry for all free models of the provider, re-ranks by recent
                  failures, then streams from the first model that answers.
                </p>
              </div>
            ) : (
              currentModel && (
              <div className="text-xs space-y-2 pt-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Target model</span>
                  <Badge variant="secondary" className="font-mono">{currentModel.id}</Badge>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Tier</span>
                  <Badge variant={currentModel.tier === "free" ? "secondary" : "outline"} className="uppercase">{currentModel.tier}</Badge>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Context window</span>
                  <span className="font-mono">{Math.round(currentModel.contextWindow / 1000)}K tokens</span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">Speed</span>
                  <Badge variant="outline" className="capitalize">{currentModel.speedTier}</Badge>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed pt-0.5">{currentModel.description}</p>
              </div>
              )
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">How it works</CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground space-y-2 leading-relaxed">
            <p>1. Your message is wrapped in an OpenAI-style <code className="font-mono text-[10px]">messages[]</code> array and sent to the gateway.</p>
            <p>2. <span className="font-medium text-foreground">Otomode</span> (top of the list) dynamically queries the model registry for all free models of the provider, re-ranks them by recent failures, and streams from the first healthy one.</p>
            <p>3. Fixed GLM models resolve straight from the registry; unknown model names fall back to the catch-all route and are served under <code className="font-mono text-[10px]">devgateway-default</code>.</p>
            <p>4. The LLM is called server-side via <code className="font-mono text-[10px]">z-ai-web-dev-sdk</code>; latency, status and previews land in Telemetry.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
