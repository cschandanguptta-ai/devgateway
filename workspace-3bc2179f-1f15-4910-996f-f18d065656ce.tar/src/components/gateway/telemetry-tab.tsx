"use client";

import { Fragment, useState } from "react";
import { BarChart3, RefreshCw, Trash2, ChevronDown } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { apiSend, timeAgo, type LogT, type StatsT } from "@/lib/gateway-client";

function StatusBadge({ status }: { status: number }) {
  if (status === 200) return <Badge variant="secondary" className="font-mono text-[10px] bg-emerald-500/10 text-emerald-400 border-emerald-500/25">200</Badge>;
  return <Badge variant="destructive" className="font-mono text-[10px]">{status}</Badge>;
}

function FragmentChild({ log: l, expanded, onToggle }: { log: LogT; expanded: boolean; onToggle: () => void }) {
  return (
    <Fragment>
      <TableRow className="cursor-pointer hover:bg-background/60" onClick={onToggle}>
        <TableCell className="font-mono text-[11px] whitespace-nowrap">
          {timeAgo(l.createdAt)}
          {l.stream && <span className="ml-1 text-[9px] text-primary">SSE</span>}
        </TableCell>
        <TableCell className="font-mono text-[11px]">
          <span className="font-semibold">{l.alias}</span>
          <span className="text-muted-foreground"> → {l.model}</span>
        </TableCell>
        <TableCell className="hidden md:table-cell">
          <span className="text-[11px] text-muted-foreground">{l.source === "playground" ? "Playground" : l.keyName}</span>
        </TableCell>
        <TableCell><StatusBadge status={l.status} /></TableCell>
        <TableCell className="font-mono text-[11px] text-right">{l.latencyMs}ms</TableCell>
        <TableCell className="hidden lg:table-cell max-w-[280px]">
          <span className={`text-[11px] truncate block ${l.error ? "text-destructive" : "text-muted-foreground"}`}>
            {l.error || l.responsePreview || "—"}
          </span>
        </TableCell>
        <TableCell>
          <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`} />
        </TableCell>
      </TableRow>
      {expanded && (
        <TableRow className="hover:bg-background/60">
          <TableCell colSpan={7} className="p-0 border-0">
            <div className="px-4 py-3 bg-background/40 grid md:grid-cols-2 gap-3 text-[11px]">
              <div className="space-y-1">
                <div className="text-[9px] uppercase tracking-wider text-muted-foreground font-semibold">Prompt (last user message)</div>
                <div className="font-mono whitespace-pre-wrap bg-background border rounded p-2.5 max-h-32 overflow-y-auto">{l.promptPreview || "—"}</div>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] uppercase tracking-wider text-muted-foreground font-semibold">Response {l.stream ? "(streamed)" : ""}</div>
                <div className={`font-mono whitespace-pre-wrap bg-background border rounded p-2.5 max-h-32 overflow-y-auto ${l.error ? "text-destructive" : ""}`}>{l.error || l.responsePreview || "—"}</div>
              </div>
              <div className="md:col-span-2 flex flex-wrap gap-x-6 gap-y-1 text-muted-foreground">
                <span>endpoint: <span className="font-mono">{l.endpoint}</span></span>
                <span>prompt: <span className="font-mono">{l.promptChars} chars</span></span>
                <span>completion: <span className="font-mono">{l.completionChars} chars</span></span>
                <span>mode: <span className="font-mono">{l.stream ? "stream" : "json"}</span></span>
                <span>id: <span className="font-mono">{l.id}</span></span>
              </div>
            </div>
          </TableCell>
        </TableRow>
      )}
    </Fragment>
  );
}

export function TelemetryTab({ logs, stats, refresh }: { logs: LogT[]; stats: StatsT | null; refresh: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null);

  const clearLogs = async () => {
    try {
      await apiSend("/api/admin/logs", "DELETE");
      toast.success("Telemetry cleared");
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to clear logs");
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <BarChart3 className="h-4 w-4 text-primary" /> Request Log
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              Every call through the gateway — auth, alias, latency and response preview. Showing latest {logs.length}.
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={refresh}>
              <RefreshCw className="h-3.5 w-3.5" /> Refresh
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive">
                  <Trash2 className="h-3.5 w-3.5" /> Clear
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all telemetry?</AlertDialogTitle>
                  <AlertDialogDescription>All request logs will be permanently deleted. Routes and keys are kept.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => void clearLogs()}>Clear logs</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <div className="text-sm text-muted-foreground py-12 text-center border border-dashed rounded-lg">
              No requests recorded yet. Route some traffic through the gateway (Playground or API) and it will show up here.
              {stats && stats.totalRequests === 0 && " Telemetry stats: 0 total calls."}
            </div>
          ) : (
            <div className="rounded-xl border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-background/80">
                    <TableHead className="text-[10px] uppercase tracking-wider">Time</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider">Alias → Target</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider hidden md:table-cell">Key / Source</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider">Status</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider text-right">Latency</TableHead>
                    <TableHead className="text-[10px] uppercase tracking-wider hidden lg:table-cell">Preview</TableHead>
                    <TableHead className="w-8" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((l) => (
                    <FragmentChild
                      key={l.id}
                      log={l}
                      expanded={expanded === l.id}
                      onToggle={() => setExpanded(expanded === l.id ? null : l.id)}
                    />
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
