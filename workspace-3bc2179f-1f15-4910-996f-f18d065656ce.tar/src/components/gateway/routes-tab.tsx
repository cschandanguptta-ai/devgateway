"use client";

import { useState } from "react";
import { GitFork, Plus, Trash2, Pencil, Power, ArrowDown } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { apiSend, type RouteT } from "@/lib/gateway-client";

export function RoutesTab({ routes, refresh }: { routes: RouteT[]; refresh: () => void }) {
  const [addOpen, setAddOpen] = useState(false);
  const [alias, setAlias] = useState("");
  const [targetModel, setTargetModel] = useState("glm-4.6");
  const [prefix, setPrefix] = useState("");
  const [desc, setDesc] = useState("");
  const [busy, setBusy] = useState(false);

  // edit state
  const [editRoute, setEditRoute] = useState<RouteT | null>(null);
  const [editPrefix, setEditPrefix] = useState("");
  const [editTarget, setEditTarget] = useState("");
  const [editDesc, setEditDesc] = useState("");

  const addRoute = async () => {
    if (!alias.trim()) return;
    setBusy(true);
    try {
      await apiSend("/api/admin/routes", "POST", { alias, targetModel, systemPrefix: prefix, description: desc });
      toast.success(`Route '${alias.trim()}' created`);
      setAddOpen(false);
      setAlias("");
      setTargetModel("glm-4.6");
      setPrefix("");
      setDesc("");
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to create route");
    } finally {
      setBusy(false);
    }
  };

  const saveEdit = async () => {
    if (!editRoute) return;
    setBusy(true);
    try {
      await apiSend(`/api/admin/routes/${editRoute.id}`, "PATCH", {
        targetModel: editTarget,
        systemPrefix: editPrefix,
        description: editDesc,
      });
      toast.success("Route updated");
      setEditRoute(null);
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to update route");
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (route: RouteT) => {
    try {
      await apiSend(`/api/admin/routes/${route.id}`, "PATCH", { enabled: !route.enabled });
      toast.success(`${route.alias} ${route.enabled ? "disabled" : "enabled"}`);
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to toggle route");
    }
  };

  const remove = async (route: RouteT) => {
    try {
      await apiSend(`/api/admin/routes/${route.id}`, "DELETE");
      toast.success(`Route '${route.alias}' deleted`);
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to delete route");
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <GitFork className="h-4 w-4 text-primary" /> Custom Route Overrides
            </CardTitle>
            <CardDescription className="text-xs mt-1">
              Advanced: optional named routes with a system-prefix override. The native catalog
              (<code className="font-mono">otomode</code> + <code className="font-mono">glm-*</code> models) needs no route —
              only unknown model names fall back to <code className="font-mono">devgateway-default</code>.
            </CardDescription>
          </div>
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Add Route
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>New model route</DialogTitle>
                <DialogDescription>Map a virtual model alias to a target model identity.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-1.5">
                  <Label htmlFor="alias">IDE model alias</Label>
                  <Input id="alias" value={alias} onChange={(e) => setAlias(e.target.value)} placeholder="e.g. gpt-5-turbo" className="font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="target">Target model</Label>
                  <Input id="target" value={targetModel} onChange={(e) => setTargetModel(e.target.value)} placeholder="glm-4.6" className="font-mono" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="prefix">System prefix (injected into every request)</Label>
                  <Textarea id="prefix" value={prefix} onChange={(e) => setPrefix(e.target.value)} placeholder="e.g. Always answer concisely in bullet points." rows={3} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="desc">Description (optional)</Label>
                  <Input id="desc" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="What is this route for?" />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
                <Button onClick={() => void addRoute()} disabled={!alias.trim() || busy}>Create route</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent className="space-y-3">
          {routes.length === 0 ? (
            <div className="text-sm text-muted-foreground py-10 text-center border border-dashed rounded-lg">
              No routes yet. Add your first alias mapping to start serving models.
            </div>
          ) : (
            routes.map((route) => (
              <div
                key={route.id}
                className={`flex flex-col sm:flex-row sm:items-center gap-3 p-3.5 rounded-xl border bg-background/50 transition-opacity ${route.enabled ? "" : "opacity-50"}`}
              >
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  <Power className={`h-3.5 w-3.5 shrink-0 ${route.enabled ? "text-emerald-400" : "text-muted-foreground"}`} />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-sm font-semibold truncate">{route.alias}</span>
                      <ArrowDown className="h-3 w-3 text-muted-foreground shrink-0" />
                      <Badge variant="secondary" className="font-mono text-[10px]">{route.targetModel}</Badge>
                      {route.systemPrefix && <Badge className="text-[10px]" variant="outline">prefix · {route.systemPrefix.length}c</Badge>}
                    </div>
                    <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                      {route.description || (route.systemPrefix ? route.systemPrefix : "No prefix · default behavior")}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0 justify-between sm:justify-end">
                  <span className="text-[11px] font-mono text-muted-foreground">{route.usageCount} calls</span>
                  <Switch checked={route.enabled} onCheckedChange={() => void toggle(route)} aria-label={`Toggle ${route.alias}`} />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => {
                      setEditRoute(route);
                      setEditPrefix(route.systemPrefix);
                      setEditTarget(route.targetModel);
                      setEditDesc(route.description);
                    }}
                    aria-label={`Edit ${route.alias}`}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" aria-label={`Delete ${route.alias}`}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete route &apos;{route.alias}&apos;?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Clients using this alias will fall back to <code className="font-mono">devgateway-default</code>. This cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => void remove(route)}>Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Edit dialog */}
      <Dialog open={!!editRoute} onOpenChange={(open) => !open && setEditRoute(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit route <span className="font-mono text-primary">{editRoute?.alias}</span></DialogTitle>
            <DialogDescription>The alias is fixed once created; adjust target, prefix and description.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="edit-target">Target model</Label>
              <Input id="edit-target" value={editTarget} onChange={(e) => setEditTarget(e.target.value)} className="font-mono" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="edit-prefix">System prefix</Label>
              <Textarea id="edit-prefix" value={editPrefix} onChange={(e) => setEditPrefix(e.target.value)} rows={4} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="edit-desc">Description</Label>
              <Input id="edit-desc" value={editDesc} onChange={(e) => setEditDesc(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditRoute(null)}>Cancel</Button>
            <Button onClick={() => void saveEdit()} disabled={busy}>Save changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
