import { GatewayApp } from "@/components/gateway/gateway-app";

export default function Home() {
  return <GatewayApp />;
}
