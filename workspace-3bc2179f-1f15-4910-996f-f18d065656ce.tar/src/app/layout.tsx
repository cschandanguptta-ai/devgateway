import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DevGateway AI Hub — OpenAI-Compatible AI Gateway",
  description:
    "Server-side OpenAI-compatible AI gateway: virtual API keys, model routing rules, streaming completions, live telemetry. Powered by z-ai-web-dev-sdk on Next.js 16.",
  keywords: ["AI gateway", "OpenAI-compatible", "API proxy", "model routing", "Next.js", "LLM"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
