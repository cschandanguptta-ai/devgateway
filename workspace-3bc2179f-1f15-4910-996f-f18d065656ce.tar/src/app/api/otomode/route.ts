import { buildOtomodePlan } from "@/lib/otomode";
import { OTOMODE_ID, OTOMODE_NAME } from "@/lib/model-registry";

export const dynamic = "force-dynamic";

// GET /api/otomode — live view of the Otomode smart-fallback plan:
// the free models of the provider as dynamically resolved from the
// model registry, re-ranked by 15-minute failure telemetry.
export async function GET() {
  try {
    const plan = await buildOtomodePlan();
    return Response.json(plan);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to build Otomode plan";
    return Response.json(
      { model: OTOMODE_ID, name: OTOMODE_NAME, provider: "zai", chain: [], error: message },
      { status: 500 }
    );
  }
}
