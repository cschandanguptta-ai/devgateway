import { db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

interface Params {
  params: Promise<{ id: string }>;
}

export async function PATCH(req: Request, { params }: Params) {
  const { id } = await params;
  let body: {
    alias?: string;
    targetModel?: string;
    systemPrefix?: string;
    description?: string;
    enabled?: boolean;
  };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const data: Record<string, unknown> = {};
  if (body.alias !== undefined) {
    const alias = body.alias.trim();
    if (!alias) return Response.json({ error: "Alias cannot be empty" }, { status: 400 });
    const clash = await db.route.findFirst({ where: { alias, NOT: { id } } });
    if (clash) return Response.json({ error: `Alias '${alias}' already exists` }, { status: 409 });
    data.alias = alias;
  }
  if (body.targetModel !== undefined) data.targetModel = body.targetModel.trim() || "glm-4.6";
  if (body.systemPrefix !== undefined) data.systemPrefix = body.systemPrefix;
  if (body.description !== undefined) data.description = body.description;
  if (body.enabled !== undefined) data.enabled = Boolean(body.enabled);

  try {
    const route = await db.route.update({ where: { id }, data });
    return Response.json({ route });
  } catch {
    return Response.json({ error: "Route not found" }, { status: 404 });
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id } = await params;
  try {
    await db.route.delete({ where: { id } });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Route not found" }, { status: 404 });
  }
}
