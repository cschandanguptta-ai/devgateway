import { ensureSeeded, db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const routes = await db.route.findMany({ orderBy: { createdAt: "asc" } });
  return Response.json({ routes });
}

export async function POST(req: Request) {
  await ensureSeeded();
  let body: { alias?: string; targetModel?: string; systemPrefix?: string; description?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const alias = (body.alias ?? "").trim();
  if (!alias) return Response.json({ error: "Alias is required" }, { status: 400 });

  const existing = await db.route.findUnique({ where: { alias } });
  if (existing) return Response.json({ error: `Alias '${alias}' already exists` }, { status: 409 });

  const route = await db.route.create({
    data: {
      alias,
      targetModel: (body.targetModel ?? "glm-4.6").trim() || "glm-4.6",
      systemPrefix: body.systemPrefix ?? "",
      description: body.description ?? "",
    },
  });
  return Response.json({ route }, { status: 201 });
}
