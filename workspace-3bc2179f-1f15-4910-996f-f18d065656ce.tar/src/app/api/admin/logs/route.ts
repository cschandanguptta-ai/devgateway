import { db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "50", 10) || 50, 200);
  const logs = await db.requestLog.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
  });
  return Response.json({ logs });
}

export async function DELETE() {
  await db.requestLog.deleteMany({});
  return Response.json({ ok: true });
}
