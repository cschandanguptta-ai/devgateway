import { db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

interface Params {
  params: Promise<{ id: string }>;
}

export async function PATCH(req: Request, { params }: Params) {
  const { id } = await params;
  let body: { name?: string; enabled?: boolean };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const data: Record<string, unknown> = {};
  if (body.name !== undefined) {
    const name = body.name.trim();
    if (!name) return Response.json({ error: "Name cannot be empty" }, { status: 400 });
    data.name = name;
  }
  if (body.enabled !== undefined) data.enabled = Boolean(body.enabled);

  try {
    const key = await db.apiKey.update({ where: { id }, data });
    return Response.json({ key });
  } catch {
    return Response.json({ error: "Key not found" }, { status: 404 });
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id } = await params;
  try {
    await db.apiKey.delete({ where: { id } });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Key not found" }, { status: 404 });
  }
}
