import { ensureSeeded, db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

function generateKey(): string {
  const rand = () => Math.random().toString(36).slice(2, 10);
  return `sk-devgw-${rand()}${rand()}`;
}

export async function GET() {
  await ensureSeeded();
  const keys = await db.apiKey.findMany({ orderBy: { createdAt: "asc" } });
  return Response.json({ keys });
}

export async function POST(req: Request) {
  await ensureSeeded();
  let body: { name?: string };
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const count = await db.apiKey.count();
  const key = await db.apiKey.create({
    data: {
      name: (body.name ?? "").trim() || `Client ${count + 1}`,
      key: generateKey(),
    },
  });
  return Response.json({ key }, { status: 201 });
}
