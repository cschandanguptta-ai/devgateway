import { ensureSeeded, db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();

  const [totalRequests, okRequests, routeCount, activeRoutes, keyCount, activeKeys] = await Promise.all([
    db.requestLog.count(),
    db.requestLog.count({ where: { status: 200 } }),
    db.route.count(),
    db.route.count({ where: { enabled: true } }),
    db.apiKey.count(),
    db.apiKey.count({ where: { enabled: true } }),
  ]);

  const recent = await db.requestLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    select: { latencyMs: true, createdAt: true, completionChars: true, promptChars: true },
  });

  const avgLatencyMs = recent.length ? Math.round(recent.reduce((a, l) => a + l.latencyMs, 0) / recent.length) : 0;
  const totalChars = recent.reduce((a, l) => a + l.completionChars + l.promptChars, 0);
  const estTotalTokens = Math.round(totalChars / 4);

  // requests per hour over the last 24h for the mini chart
  const byHour: { hour: string; count: number }[] = [];
  const now = new Date();
  for (let i = 23; i >= 0; i--) {
    const slotStart = new Date(now.getTime() - i * 3600_000);
    slotStart.setMinutes(0, 0, 0);
    const slotEnd = new Date(slotStart.getTime() + 3600_000);
    const count = recent.filter((l) => {
      const t = new Date(l.createdAt).getTime();
      return t >= slotStart.getTime() && t < slotEnd.getTime();
    }).length;
    byHour.push({ hour: slotStart.toISOString().slice(11, 13) + ":00", count });
  }

  return Response.json({
    totalRequests,
    okRequests,
    successRate: totalRequests ? Math.round((okRequests / totalRequests) * 100) : 100,
    avgLatencyMs,
    routeCount,
    activeRoutes,
    keyCount,
    activeKeys,
    estTotalTokens,
    byHour,
  });
}
