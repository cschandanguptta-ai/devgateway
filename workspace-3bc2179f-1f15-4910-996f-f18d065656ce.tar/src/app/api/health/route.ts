import { db } from "@/lib/gateway";

export const dynamic = "force-dynamic";

// Gateway health + route/key summary, used by the dashboard status pill.
export async function GET() {
  try {
    const [totalRoutes, activeRoutes, totalKeys] = await Promise.all([
      db.route.count(),
      db.route.count({ where: { enabled: true } }),
      db.apiKey.count(),
    ]);
    return Response.json({ status: "online", totalRoutes, activeRoutes, totalKeys, db: "ok" });
  } catch {
    return Response.json({ status: "degraded", db: "error" }, { status: 500 });
  }
}
