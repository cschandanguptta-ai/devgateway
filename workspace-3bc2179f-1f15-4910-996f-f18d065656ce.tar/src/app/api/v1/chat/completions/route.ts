import { ensureSeeded, authenticate, runChatCompletion, openAIError } from "@/lib/gateway";
import type { GatewayMessage } from "@/lib/gateway";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

interface ChatCompletionBody {
  model?: string;
  messages?: unknown;
  stream?: boolean;
  temperature?: number;
  max_tokens?: number;
}

function parseMessages(raw: unknown): GatewayMessage[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((m): m is { role: string; content: unknown } => !!m && typeof m === "object" && "role" in m)
    .map((m) => ({
      role: m.role === "assistant" ? "assistant" : m.role === "system" ? "system" : "user",
      content: typeof m.content === "string" ? m.content : Array.isArray(m.content)
        ? m.content.map((p) => (typeof p === "string" ? p : (p as { text?: string })?.text || JSON.stringify(p))).join("\n")
        : JSON.stringify(m.content ?? ""),
    }));
}

export async function POST(req: Request) {
  await ensureSeeded();

  const auth = await authenticate(req.headers.get("authorization"));
  if (!auth.ok) return auth.response;

  let body: ChatCompletionBody;
  try {
    body = (await req.json()) as ChatCompletionBody;
  } catch {
    return openAIError(400, "Request body must be valid JSON.");
  }

  const messages = parseMessages(body.messages);
  if (messages.length === 0) {
    return openAIError(400, "`messages` must be a non-empty array of { role, content } objects.");
  }

  return runChatCompletion({
    messages,
    alias: body.model,
    apiKeyRecord: auth.key,
    source: "api",
    stream: body.stream !== false,
    temperature: body.temperature,
    maxTokens: body.max_tokens,
  });
}
