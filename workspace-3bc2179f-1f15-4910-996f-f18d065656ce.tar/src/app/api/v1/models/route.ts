import { ensureSeeded } from "@/lib/gateway";
import { getModelsByProvider, OTOMODE_ID, OTOMODE_NAME } from "@/lib/model-registry";

export const dynamic = "force-dynamic";

// OpenAI-compatible model listing: GET /api/v1/models
// The catalog is native: the synthetic "Otomode" model (intra-provider smart
// fallback) is injected at the TOP, followed by the provider's registry models.
export async function GET() {
  await ensureSeeded();
  const models = getModelsByProvider("zai");
  const created = Math.floor(Date.now() / 1000);
  return Response.json({
    object: "list",
    data: [
      {
        id: OTOMODE_ID,
        object: "model",
        created,
        owned_by: "devgateway",
        devgateway: {
          synthetic: true,
          smartFallback: true,
          description:
            "Otomode — intra-provider smart fallback. Dynamically serves from the first healthy free model of the provider; no fixed route required.",
        },
      },
      ...models.map((m) => ({
        id: m.id,
        object: "model",
        created,
        owned_by: "devgateway",
        devgateway: {
          name: m.name,
          tier: m.tier,
          contextWindow: m.contextWindow,
          speedTier: m.speedTier,
          description: m.description,
        },
      })),
    ],
  });
}
