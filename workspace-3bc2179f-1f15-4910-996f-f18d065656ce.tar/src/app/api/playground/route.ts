import { ensureSeeded, runChatCompletion, openAIError } from "@/lib/gateway";
import type { GatewayMessage } from "@/lib/gateway";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

// Playground endpoint: same gateway pipeline, but bypasses API-key auth
// (requests are tagged as source=playground in telemetry).
export async function POST(req: Request) {
  await ensureSeeded();

  let body: { messages?: unknown; model?: string; stream?: boolean };
  try {
    body = await req.json();
  } catch {
    return openAIError(400, "Invalid JSON body.");
  }

  if (!Array.isArray(body.messages)) {
    return openAIError(400, "`messages` must be an array.");
  }

  const messages: GatewayMessage[] = body.messages
    .filter((m): m is { role: string; content: string } => !!m && typeof m === "object" && typeof (m as { content?: unknown }).content === "string")
    .map((m) => ({
      role: m.role === "assistant" ? "assistant" : m.role === "system" ? "system" : "user",
      content: m.content,
    }));

  if (messages.length === 0) {
    return openAIError(400, "No valid messages provided.");
  }

  return runChatCompletion({
    messages,
    alias: body.model,
    apiKeyRecord: null,
    source: "playground",
    stream: body.stream !== false,
  });
}
