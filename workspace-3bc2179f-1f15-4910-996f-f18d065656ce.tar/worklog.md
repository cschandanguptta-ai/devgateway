# Project Worklog

---
Task ID: 1
Agent: Super Z (main agent)
Task: Analyze uploaded devgateway_proxy_hub.html and build an AI application (Next.js 16 + TypeScript + shadcn/ui + Prisma + z-ai-web-dev-sdk)

Work Log:
- Analyzed `/home/z/my-project/upload/devgateway_proxy_hub.html` (879 lines): a single-file React (Babel-standalone) app "DevGateway Proxy Hub v5.0" — a browser-based OpenAI-to-Gemini proxy that polls an ngrok tunnel for queued IDE requests, relays them to Gemini Canvas, and streams tokens back. State persisted in localStorage; several tabs (IDE Settings, Telemetry) were stubs.
- Initialized fullstack environment via init script; verified Next.js 16 dev server on port 3000.
- Designed Prisma schema (Route, ApiKey, RequestLog) in `prisma/schema.prisma`; pushed to SQLite at `db/custom.db`.
- Built gateway core `src/lib/gateway.ts`: ensureSeeded (5 default alias routes + master key `sk-devgw-master-key`), Bearer-token auth, alias→route resolution with `devgateway-default` catch-all, system-prefix injection, z-ai-web-dev-sdk calls (stream + non-stream), strict OpenAI wire-format normalization (SSE TransformStream + JSON), telemetry logging with latency/chars/previews, usage counters.
- Built API routes: `POST /api/v1/chat/completions` (OpenAI-compatible, SSE + JSON), `GET /api/v1/models`, `POST /api/playground` (bypass-auth pipeline), `/api/admin/routes[/id]` (CRUD), `/api/admin/keys[/id]` (CRUD), `GET|DELETE /api/admin/logs`, `GET /api/admin/stats` (24h histogram), `GET /api/health`.
- Built dashboard UI (single `/` route, dark slate+blue theme from the original design): `src/app/page.tsx` + `src/components/gateway/{gateway-app,overview-tab,playground-tab,routes-tab,keys-tab,ide-config-tab,telemetry-tab}.tsx`, shared client helpers in `src/lib/gateway-client.ts`.
- Customized `.dark` palette in globals.css (slate-900 bg, slate-800 cards, blue-500 primary) + custom scrollbars + ping animation.
- Fixed lint errors: `db` re-export from gateway lib; replaced setState-in-effect in IDE config tab with lazy initializer + derived state.
- Browser verification (agent-browser): fixed a React "Invalid prop data-state on Fragment" error by replacing Collapsible-asChild table rows with a manual expansion row component. Fixed mobile tab labels (non-existent `xs:` breakpoint → always-visible labels with horizontal scroll).
- Verified via curl: 200 non-stream + SSE stream completions, system-prefix injection (pirate test), 401 paths (no/bad key), unknown-model fallback, playground endpoint, per-route usage counters.
- Verified via browser: Overview live stats + 24h chart + activity feed; Playground streamed real LLM answer (546ms); telemetry row expansion (prompt/response previews); route creation via dialog (llama-3-70b) then confirmed via API (prefix applied: true); key generation via dialog then confirmed auth 200; IDE config snippets; mobile 390px responsiveness; sticky footer behavior.

Stage Summary:
- Deliverable: "DevGateway AI Hub v6.0 Server Edition" — a working OpenAI-compatible AI gateway replacing the browser-polling hack with real server-side implementation.
- Key files: src/lib/gateway.ts, src/app/api/** (9 route handlers), src/components/gateway/** (7 components), prisma/schema.prisma, src/app/{page,layout,globals.css}.
- Endpoint contract: `POST /api/v1/chat/completions` with `Authorization: Bearer sk-devgw-*`, body `{model, messages, stream}` → OpenAI SSE chunks or JSON; `GET /api/v1/models` lists enabled aliases.
- Seeded state: 5 routes (gpt-4o, gpt-4o-mini, claude-3-5-sonnet, deepseek-chat, devgateway-default) + 1 master key (sk-devgw-master-key).

---
Task ID: 2
Agent: Super Z (main agent)
Task: Implement Otomode (intra-provider smart fallback) + native GLM model catalog (no alias mapping layer)

Work Log:
- Created `src/lib/model-registry.ts`: registry of zai-provider models (glm-4.6 p10, glm-4.5-air p20, glm-4.5-flash p30 — all free tier; glm-4.5v paid/disabled) with `getModelsByProvider` / `getFreeModelsByProvider` dynamic queries.
- Created `src/lib/otomode.ts`: `buildOtomodePlan()` (dynamic registry query + 15-min telemetry health re-ranking; degraded models sink) and `runOtomodeCompletion()` — sequential fallback engine: create() throws / empty content / SSE error chunks / 10s probe timeout all advance to the next candidate; streaming commits only after the first verified content chunk (buffered prefix replayed verbatim through the OpenAI transformer); failed attempts logged as individual 502 telemetry rows feeding future health ranking; success exposes X-Otomode-Served-By/Chain/Attempts headers + devgateway.otomode JSON meta.
- Refactored `src/lib/gateway.ts`: intercepts alias `otomode` at the top of runChatCompletion (dynamic import, no init cycle); new `ResolvedTarget`/`resolveModelTarget` — resolution order: registry models natively → custom DB routes (prefix overrides) → devgateway-default catch-all (unknown names NOT kept: wire name = serving route); SDK call now passes `model: targetModel` making alias→target real; exported helpers for otomode reuse; DEFAULT_ROUTES reduced to devgateway-default only.
- New `GET /api/otomode`: live fallback plan (chain + health) for the dashboard.
- `GET /api/v1/models`: injected synthetic Otomode entry at the TOP, followed by registry glm models (alias list removed per spec).
- Playground UI: Otomode (Sparkles + SMART badge) injected at top of model selector and default-selected; live fallback-chain panel with tier/health indicators + refresh; registry metadata panel (tier/context/speed) for fixed glm models; ⚡ otomode → <servedBy> latency badge on assistant messages.
- IDE Config tab: catalog otomode + glm-*; snippets use otomode as sample model; API surface lists /api/otomode. Overview + Model Router copy reframed ("Custom Route Overrides" — advanced, optional).
- Deleted 5 legacy alias routes from DB (gpt-4o, gpt-4o-mini, claude-3-5-sonnet, deepseek-chat, llama-3-70b); only devgateway-default remains.
- Verification: lint clean; curl — models list order (otomode→glm-4.6→air→flash), otomode stream (TTFB 404ms, served-by glm-4.6) + non-stream JSON meta, native glm-4.6/glm-4.5-air resolution, unknown → devgateway-default with aliasFallbackUsed:true; fallback mechanics proven via scripts/test-otomode-probe.ts (10/10: error-chunk detection, split-content probe + verbatim byte replay, empty-stream fail, commit replay → valid OpenAI SSE). Note: upstream tolerates ANY model id (serves via default), so real outages are the only fallback trigger; chain succeeds on attempt #1 in practice.
- Browser E2E: Playground renders Otomode default + live chain; UI message streamed with ⚡ otomode → glm-4.6 · 491 ms badge; dropdown order verified; glm-4.5-air registry panel; IDE Config updated. Fixed a leftover `enabledRoutes` ReferenceError caught by browser verification.

Stage Summary:
- Deliverable: DevGateway AI Hub with Otomode smart fallback + native model catalog (otomode + glm-4.6/glm-4.5-air/glm-4.5-flash), alias mapping layer removed.
- Key files: src/lib/model-registry.ts (NEW), src/lib/otomode.ts (NEW), src/app/api/otomode/route.ts (NEW), src/lib/gateway.ts, src/app/api/v1/models/route.ts, src/components/gateway/{playground-tab,ide-config-tab,routes-tab,overview-tab}.tsx, scripts/test-otomode-probe.ts (NEW).
