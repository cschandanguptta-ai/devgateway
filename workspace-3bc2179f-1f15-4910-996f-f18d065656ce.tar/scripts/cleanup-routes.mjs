// One-off cleanup: remove legacy alias routes, keep devgateway-default
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const legacy = ["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet", "deepseek-chat", "llama-3-70b"];
const res = await db.route.deleteMany({ where: { alias: { in: legacy } } });
console.log("deleted legacy alias routes:", res.count);
const remaining = await db.route.findMany({ select: { alias: true, enabled: true } });
console.log("remaining routes:", JSON.stringify(remaining));
await db.$disconnect();
