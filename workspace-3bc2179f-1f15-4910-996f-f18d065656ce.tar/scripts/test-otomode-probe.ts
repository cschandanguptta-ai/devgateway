/**
 * Otomode fallback-mechanics verification with synthetic upstream streams.
 * Run: bun run scripts/test-otomode-probe.ts
 */
import { probeUpstreamStream, replayProbedStream, scanSseForSignal } from "@/lib/otomode";
import { createSSETransformer } from "@/lib/gateway";

const enc = new TextEncoder();
const dec = new TextDecoder();

function sseStream(chunks: string[], delayMs = 5): ReadableStream<Uint8Array> {
  return new ReadableStream<Uint8Array>({
    async start(c) {
      for (const ch of chunks) {
        await new Promise((r) => setTimeout(r, delayMs));
        c.enqueue(enc.encode(ch));
      }
      c.close();
    },
  });
}

const contentChunks = [
  'data: {"choices":[{"delta":{"content":"Hel"}}]}\n\n',
  'data: {"choices":[{"delta":{"content":"lo"}}]}\n\n',
  "data: [DONE]\n\n",
];

let pass = 0;
let fail = 0;
function check(name: string, cond: boolean, extra = "") {
  if (cond) {
    pass++;
    console.log(`  ✓ ${name} ${extra}`);
  } else {
    fail++;
    console.log(`  ✗ ${name} ${extra}`);
  }
}

// --- scanSseForSignal -------------------------------------------------------
console.log("[1] scanSseForSignal");
{
  const r1 = scanSseForSignal('data: {"error":{"message":"rate limited"}}\n\n');
  check("detects error chunk", r1.signal.error === "rate limited");
  const r2 = scanSseForSignal('data: {"choices":[{"delta":{"content":"Hi"}}]}\n\n');
  check("detects content chunk", r2.signal.hasContent === true);
  const r3 = scanSseForSignal('data: {"choices":[{"delta":{"content":"He"}}]}\n\ndata: {"cho');
  check("keeps partial trailing line as leftover", r3.signal.hasContent === true && r3.leftover === 'data: {"cho');
  const r4 = scanSseForSignal("data: [DONE]\n\n: comment\n\n");
  check("ignores [DONE] and comments", r4.signal.hasContent === false && !r4.signal.error);
}

// --- probeUpstreamStream ----------------------------------------------------
console.log("[2] probeUpstreamStream");
{
  const a = await probeUpstreamStream(sseStream(['data: {"error":{"message":"upstream boom"}}\n\n', ...contentChunks]));
  check("error chunk -> probe fails with detail", a.ok === false && a.ok !== undefined && (a as { detail?: string }).detail === "upstream boom");

  const b = await probeUpstreamStream(sseStream(contentChunks));
  const okB = b.ok === true;
  const bufferedText = okB ? (b as { buffered: Uint8Array[] }).buffered.map((u) => dec.decode(u)).join("") : "";
  check("content -> probe succeeds", okB);
  check("buffered prefix contains first content bytes", bufferedText.includes('"Hel"'), `(${(b as { buffered?: Uint8Array[] }).buffered?.length ?? 0} chunk buffered)`);

  const c = await probeUpstreamStream(sseStream([": keepalive\n\n", "data: [DONE]\n\n"]));
  check("stream ending without content -> probe fails", c.ok === false);
}

// --- replayProbedStream + transformer (commit path) --------------------------
console.log("[3] commit: replayProbedStream through OpenAI transformer");
{
  const probe = await probeUpstreamStream(sseStream(contentChunks));
  if (!probe.ok) {
    check("probe setup for commit test", false);
  } else {
    const transformer = createSSETransformer({
      completionId: "test-otomode",
      alias: "otomode",
      created: Math.floor(Date.now() / 1000),
      promptChars: 10,
      onDone: () => {}, // no telemetry in test
      onError: () => {},
    });
    const out = replayProbedStream(probe, transformer);
    const reader = out.getReader();
    let sse = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) sse += dec.decode(value);
    }
    const deltas = [...sse.matchAll(/"delta":\{"content":"([^"]*)"\}/g)].map((m) => m[1]);
    check("replays buffered prefix + live tail", deltas.join("") === "Hello", `(got: "${deltas.join("")}")`);
    check("emits valid OpenAI SSE finish", sse.includes('"finish_reason":"stop"') && sse.includes("data: [DONE]"));
  }
}

console.log(`\nResult: ${pass} passed, ${fail} failed`);
process.exit(fail > 0 ? 1 : 0);
